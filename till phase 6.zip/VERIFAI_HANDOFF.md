# VerifAI — Full Build Handoff

## What You Are Building

VerifAI is an AI hallucination detection web app. It takes a paragraph as input, extracts factual claims, checks each claim against Wikipedia via RAG, and classifies each claim as factual, hallucinated, or uncertain using a fine-tuned DeBERTa-v3-large model. The app runs entirely on localhost — no deployment required.

The ZIP file attached to this message contains five screen designs (HTML + screenshots) and a DESIGN.md. Use them as the visual reference for all UI work.

---

## Repository Structure

```
verifai/
├── frontend/   ← Next.js + Tailwind
└── backend/    ← FastAPI
```

Monorepo. Everything runs locally.

---

## Backend

### Framework
FastAPI.

### Folder Structure

```
backend/
├── main.py                  ← FastAPI app, lifespan, middleware
├── config.py                ← loads all settings from .env
├── requirements.txt
├── .env                     ← gitignored
├── routers/
│   └── verify.py            ← /verify endpoint only
├── services/
│   ├── extractor.py         ← claim extraction pipeline
│   ├── retriever.py         ← RAG: Qdrant + BM25s + cross-encoder reranker
│   ├── classifier.py        ← DeBERTa-v3-large inference
│   └── explainer.py         ← Ollama explanation call
└── models/
    └── schemas.py           ← Pydantic request/response shapes
```

### Model Loading
All models (DeBERTa, spaCy, cross-encoder reranker, Qdrant client) load **once at startup** using FastAPI's lifespan context manager. Never load per request.

```python
from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.classifier = load_deberta_model()
    app.state.retriever = load_rag_pipeline()
    yield

app = FastAPI(lifespan=lifespan)
```

### Request Handling — SSE (Server-Sent Events)
The `/verify` endpoint uses SSE to stream progress events to the frontend as each pipeline step completes. This drives the real-time 4-step loading UI.

The backend streams four events in sequence:
```json
{ "step": 1, "status": "extracting" }
{ "step": 2, "status": "retrieving" }
{ "step": 3, "status": "classifying" }
{ "step": 4, "status": "complete", "data": { ...full response... } }
```

**Critical:** Keep pipeline logic completely separate from the SSE transport layer. The core pipeline should be a plain async function that takes a paragraph and returns the full result. SSE wraps that function. This makes reverting to synchronous easy if needed — only the transport layer changes, not the pipeline.

### Configuration
`.env` file + `python-dotenv`. All environment-specific settings live in `.env`.

```
# .env
MODEL_PATH=models/deberta
QDRANT_URL=http://localhost:6333
OLLAMA_URL=http://localhost:11434
OLLAMA_MODEL=llama3.1:8b
MAX_CHARS=2000
```

Add the following environment variables when using the local Ollama extractor/explainer setup:
```
EXTRACTOR_PROVIDER=ollama
EXTRACTOR_MODEL=llama3.1:8b
EXPLAINER_PROVIDER=ollama
EXPLAINER_MODEL=llama3.1:8b
EXPLAINER_TIMEOUT_S=15.0
```

`config.py` loads these via `os.getenv()`. Every other file imports from `config.py`. `.env` is gitignored.

### CORS
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_methods=["POST", "OPTIONS"],
    allow_headers=["Content-Type"],
)
```

### Explanation LLM
Ollama running llama3.1:8b. Called once per hallucinated or uncertain claim only. Factual claims do not get an explanation call. Wrap each call in try/except — if the explainer fails for a single claim, return `null` for that claim's explanation and continue. Do not abort the whole response.

```python
try:
    explanation = await explainer.explain(claim, evidence)
except Exception:
    explanation = None
```

### API Contract — Locked In

```
POST /verify
Content-Type: application/json

Request:
{ "paragraph": "user input text" }
```

SSE response streams step events, then final payload:
```json
{
  "claims_count": 6,
  "hallucination_rate": 0.33,
  "verdicts": {
    "factual": 3,
    "hallucinated": 2,
    "uncertain": 1
  },
  "claims": [
    {
      "id": 1,
      "text": "Einstein received the Nobel Prize in Physics in 1922.",
      "source_text": "The Nobel Prize in Physics 1921 was awarded...",
      "start_offset": 128,
      "end_offset": 162,
      "verdict": "hallucinated",
      "confidence": 0.88,
      "source_relevance": 0.82,
      "explanation": "The claim states 1922 but Wikipedia records show the prize was awarded in 1921.",
      "evidence": {
        "snippet": "The Nobel Prize in Physics 1921 was awarded...",
        "article_title": "Nobel Prize in Physics",
        "article_url": "https://en.wikipedia.org/wiki/Nobel_Prize_in_Physics"
      }
    }
  ]
}

Note: the fields `source_text`, `start_offset`, and `end_offset` are included per-claim to support frontend highlighting (they are additive to the existing contract and enable Phase 11 UI work). 
```

- `verdict` is always exactly one of: `"factual"`, `"hallucinated"`, `"uncertain"`
- `explanation` is `null` for factual claims
- `evidence` is present on **all claims**. If no evidence was found, `evidence` is `null` and the verdict is `"uncertain"`

### Error Handling

**Error response shape:**
```json
{
  "error": true,
  "code": "PIPELINE_FAILURE",
  "message": "Something went wrong while classifying claims."
}
```

**Error codes:**
| Code | Trigger | HTTP Status |
|---|---|---|
| `INVALID_INPUT` | Empty or over 2000 chars | 422 |
| `NO_CLAIMS_FOUND` | Extractor returned zero claims | 200 |
| `RETRIEVAL_FAILURE` | Qdrant unreachable | 500 |
| `CLASSIFICATION_FAILURE` | DeBERTa inference failed | 500 |
| `EXPLANATION_FAILURE` | Ollama failed — degrade gracefully, do not abort | — |
| `PIPELINE_FAILURE` | Catch-all | 500 |

Fail the whole request only if extraction or classification fails. Degrade gracefully for explanation failures.

---

## Frontend

### Stack
Next.js (App Router) + Tailwind CSS.

### Folder Structure

```
frontend/
├── .env.local                        ← NEXT_PUBLIC_API_URL=http://localhost:8000
├── app/
│   ├── layout.js                     ← global font, background, metadata
│   ├── page.js                       ← landing page
│   └── verify/
│       └── page.js                   ← input + results (same page)
├── components/
│   ├── landing/
│   │   ├── Hero.jsx                  ← headline, subtext, CTA
│   │   └── InfoBlocks.jsx            ← 3 info blocks
│   ├── verify/
│   │   ├── InputSection.jsx          ← textarea, char counter, submit
│   │   ├── LoadingIndicator.jsx      ← 4-step horizontal progress
│   │   ├── ResultsSummary.jsx        ← hallucination rate % + 4 ring charts
│   │   ├── HighlightedParagraph.jsx  ← inline color-coded claim highlights
│   │   └── ClaimCards.jsx            ← scrollable claim card container
│   └── ui/
│       ├── ClaimCard.jsx             ← single card
│       ├── RingChart.jsx             ← reusable SVG ring chart
│       └── VerdictBadge.jsx          ← verdict label chip
├── context/
│   └── VerifAIContext.jsx            ← global state
├── hooks/
│   └── useVerify.js                  ← SSE fetch logic
└── styles/
    └── globals.css                   ← Tailwind base
```

### State Management
React Context. `VerifAIContext` holds:
- `paragraph` — the user's input text
- `currentStep` — integer 1–4, drives loading UI
- `response` — full API response object, null until complete
- `error` — error object or null
- `status` — one of: `"idle"` | `"loading"` | `"complete"` | `"error"`

### SSE Handling
Use `fetch` with a streaming reader (not `EventSource` — that only supports GET).

```javascript
// hooks/useVerify.js
const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/verify`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ paragraph })
});

const reader = response.body.getReader();
const decoder = new TextDecoder();

while (true) {
  const { done, value } = await reader.read();
  if (done) break;

  const lines = decoder.decode(value).split("\n");
  for (const line of lines) {
    if (!line.startsWith("data:")) continue;
    const event = JSON.parse(line.slice(5));

    if (event.status === "complete") {
      setResponse(event.data);
      setStatus("complete");
    } else {
      setCurrentStep(event.step);
    }
  }
}
```

The hook exposes: `{ submit, currentStep, status, error }`. The input screen calls the hook and knows nothing about SSE internals.

**Revert plan:** If SSE doesn't work, replace the streaming fetch with a plain awaited fetch and remove step tracking. The hook interface stays the same — no other files change.

### Navigation & State Reset
- Clicking the VerifAI logo navigates to `/` and **fully resets all context state** — clears paragraph, response, currentStep, error, status back to idle.
- When the user submits, the screen transitions immediately to the loading state. There is no way to edit mid-analysis.
- When the user submits a new request from the results screen (not applicable — they must use the logo to go home first).
- **"Try again" button on error screen:** Resets all context state and returns to the input screen.
- **"Back to home" link on error screen:** Resets all context state and navigates to `/`.

---

## Design System

Reference the DESIGN.md and HTML files in the ZIP for full detail. Key tokens:

### Colors
| Token | Hex | Usage |
|---|---|---|
| `background` | `#F5F3EF` | Page background (non-negotiable) |
| `surface-container-lowest` | `#ffffff` | Cards — elevated paper surface |
| `primary` | `#1f108e` | CTA buttons, active step, links, focus borders |
| `on-surface` | `#161a32` | Primary text |
| `on-surface-variant` | `#464553` | Secondary/muted text |
| `outline-variant` | `#c8c4d5` | Dividers, card borders |
| `surface-container-low` | `#f4f2ff` | Evidence block background |
| `verdict-sage` | `#4F7942` | Factual |
| `verdict-red` | `#D21F3C` | Hallucinated |
| `verdict-amber` | `#FFBF00` | Uncertain |
| `error` | `#ba1a1a` | Hallucination rate percentage text |

Inline claim highlights:
```css
.highlight-sage  { background-color: rgba(79, 121, 66, 0.15);  border-bottom: 2px solid #4F7942; }
.highlight-red   { background-color: rgba(210, 31, 60, 0.15);  border-bottom: 2px solid #D21F3C; }
.highlight-amber { background-color: rgba(255, 191, 0, 0.15);  border-bottom: 2px solid #FFBF00; }
```

### Typography
- **Source Serif 4** — all headings and display text (Google Fonts)
- **Inter** — all body text, labels, data, UI copy (Google Fonts)

| Scale | Font | Size | Weight |
|---|---|---|---|
| display-lg | Source Serif 4 | 48px / lh 56px | 700, tracking -0.02em |
| headline-lg | Source Serif 4 | 32px / lh 40px | 600 |
| headline-md | Source Serif 4 | 24px / lh 32px | 600 |
| body-lg | Inter | 18px / lh 28px | 400 |
| body-md | Inter | 16px / lh 24px | 400 |
| body-sm | Inter | 14px / lh 20px | 400 |
| label-md | Inter | 14px / lh 16px | 600, tracking 0.01em |
| label-sm | Inter | 12px / lh 14px | 500 |

### Spacing & Shape
- 4px baseline grid
- Desktop margins: 48px
- Max content width: 1200px
- Standard border radius: 4px — buttons, inputs, verdict badges
- Large border radius: 8px — main content cards
- Cards: white background, `1px solid #E5E2DA`, no shadow
- Depth via tonal layers, not shadows
- Hover states: subtle background color shift, no shadow increase

---

## Screen-by-Screen Spec

### Screen 1 — Landing Page (`/`)
Reference file: `verifai_landing_with_three_info_blocks/`

- Full-page centered layout on stone background
- **Header:** VerifAI logo (shield icon + wordmark) top-left. Clicking resets all state and navigates to `/`.
- **Hero:** "Is this actually true?" in Source Serif 4 display-lg, centered. Subtext body copy centered below. Primary indigo CTA button "Let's find out →" navigates to `/verify`.
- **Info blocks:** Three items in a horizontal row: "What is an AI hallucination?", "How do I reduce AI hallucinations?", "What type of hallucinations does VerifAI catch?" — each with an arrow/external link icon.
- **Footer:** VerifAI wordmark left, "© 2026 VerifAI. Academic Integrity Verified." right.

### Screen 2 — Input (`/verify`, status: idle)
Reference file: `verifai_interactive_analysis_flow/`

- **Heading:** "What would you like to fact-check?" in Source Serif 4 headline-lg
- **Textarea:** White background, 1px stone border, 8px radius. Focus: border switches to indigo. Placeholder: "Paste a paragraph to verify..." Hard limit: 2000 characters.
- **Inside card footer row:** Character counter "0 / 2,000" bottom-left. Primary "Analyze" button bottom-right. Muted "~3–8 seconds per analysis" below button.
- **Validation (client-side, before calling backend):**
  - Empty submit: inline error below textarea
  - Over 2000 chars: inline error below textarea, button disabled

### Screen 3 — Loading (`/verify`, status: loading)
Reference file: `verifai_fixed_sequential_loading_sequence/`

- Input section hidden. Full page shows loading view.
- **Label:** "ANALYZING YOUR TEXT..." uppercase label-md, centered
- **4-step horizontal indicator:** Steps connected by a horizontal line. Each step: icon in rounded-square container + label below.
  - Steps: Extracting claims → Retrieving evidence → Classifying claims → Preparing results
  - Pending: muted icon and label
  - Active: indigo container, indigo label, spinner on icon
  - Completed: green container, checkmark icon, muted label
- Steps update in real time from SSE events.

### Screen 4 — Results (`/verify`, status: complete)
Reference file: `verifai_comprehensive_evidence_analysis/`

Two-column layout (7/12 left, 5/12 right):

**Left column — Verification Map card (white, stone border, 8px radius):**
- Title "Verification Map" headline-md
- Hairline divider
- Original paragraph with inline claim highlights. Each claim is wrapped in a span with the appropriate highlight class. Clicking a highlighted span scrolls to the corresponding card on the right.
- Color legend: three dot + label pairs (● Factual  ● Hallucinated  ● Uncertain)
- Hairline divider
- **Quick Statistics:**
  - "QUICK STATISTICS" uppercase label-sm label
  - Left: Large bold hallucination rate percentage in `error` color (e.g. "25%"), "RATE" label below it, then "Hallucination Rate" bold and "X of Y claims" muted. This is a **plain number, not a ring chart**.
  - Thin vertical divider
  - Right: Four SVG ring charts — Total Claims (indigo), Factual (sage), Hallucinated (red), Uncertain (amber). Each ring fills proportionally to share of total claims. Number centered inside. Uppercase label-sm below.

**Right column — Detailed Breakdown:**
- "DETAILED BREAKDOWN" uppercase label-sm
- Scrollable container, max-height 700px, fade gradient at bottom
- Cards ordered same as claims appear in paragraph
- Each card: white bg, stone border, 8px radius, **4px colored left border** in verdict color
- **Card contents:**
  - Top row: claim text (label-md) left, VerdictBadge right (verdict color text, 15% opacity bg, uppercase, 4px radius)
  - Confidence bar: "Confidence" label + percentage in verdict color, thin progress bar in verdict color
  - Source relevance bar: "Source relevance" + ⓘ icon + percentage in primary indigo, thin bar in primary indigo
  - Evidence block (**all claims**): `surface-container-low` bg, bolt icon, italic body-sm Wikipedia snippet. For hallucinated/uncertain: Wikipedia article link in indigo underlined appended to snippet.
  - Explanation block (**hallucinated + uncertain only**): 2–3 sentence plain-language explanation above or within the evidence block. If `explanation` is `null`, omit silently — no empty box.

### Screen 5 — Error State
Reference file: `verifai_error_state/`

- Centered white card on stone background, 8px radius, stone border
- Exclamation icon in rounded indigo-tinted container
- "Oops, something went wrong!" headline-md Source Serif 4
- Plain-language message body text (see table below)
- Primary "Try again" button — resets all state, returns to input screen
- "Back to home" secondary text link — resets all state, navigates to `/`
- Error code **not shown** to user

| Code | User-facing message |
|---|---|
| `NO_CLAIMS_FOUND` | "We couldn't find any checkable claims in this text. Try a paragraph with more specific factual statements." |
| `RETRIEVAL_FAILURE` | "We had trouble searching for evidence. Please try again." |
| `CLASSIFICATION_FAILURE` | "Something went wrong while analyzing your claims. Please try again." |
| `PIPELINE_FAILURE` | "Something went wrong on our end. Please try again." |
| Network error | "Couldn't reach the server. Make sure the backend is running." |

---

## Edge Cases

- **Zero claims found:** Show error screen with `NO_CLAIMS_FOUND` message.
- **Single claim:** Results render normally. Ring charts must not break with low numbers — zero-value rings render as empty rings.
- **All claims same verdict:** Zero-value rings render as empty rings, not broken or missing elements.
- **Many claims / dense highlights:** Highlighted paragraph wraps gracefully. Claim cards scroll — layout never breaks.
- **Long claim text:** Text wraps inside card — no overflow.
- **No evidence for a claim:** `evidence` is `null`, verdict is `"uncertain"`, evidence block is not rendered — no empty box shown.
- **Explanation is null:** Explanation block omitted silently — no empty box shown.
- **Logo click at any point:** Resets all context state and navigates to `/`.
