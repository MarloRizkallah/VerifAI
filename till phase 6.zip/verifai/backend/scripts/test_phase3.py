"""
test_phase3.py
===============
Phase 3 verification script. Run this from the backend/ directory to confirm
the extractor wrapper and sentence-level span attribution work as specified.

Usage
-----
    cd backend
    python scripts/test_phase3.py

This script loads the extractor and runs three test paragraphs. It asserts
that for every returned claim, the slice paragraph[start:end] == source_text.
"""

import os
import sys
import time
from pathlib import Path

# Make services/ importable when running from backend/
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services.extractor import load_extractor, extract_with_spans  # noqa: E402


try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


TEST_1 = (
    "Einstein was born in Germany in 1879. "
    "He won the Nobel Prize in 1921. "
    "He later moved to the United States."
)

TEST_2 = (
    "Apple was founded by Steve Jobs in 1976. "
    "It released the first iPhone in 2007. "
    "Jobs left the company in 1985 but returned in 1997."
)

TEST_3 = (
    "The Titanic was built in Belfast and launched in 1911. "
    "It sank on April 15, 1912 after hitting an iceberg."
)

TESTS = [TEST_1, TEST_2, TEST_3]


def _env(key: str, default=None, required: bool = False):
    val = os.getenv(key, default)
    if required and val is None:
        sys.exit(f"FATAL: required env var {key} is not set (check .env)")
    return val


def main():
    print("=" * 70)
    print("PHASE 3 VERIFICATION — loading extractor")
    print("=" * 70)

    # Use environment to control LLM provider/model if desired
    EXTRACTOR_PROVIDER = _env("EXTRACTOR_PROVIDER", "ollama")
    EXTRACTOR_MODEL = _env("EXTRACTOR_MODEL", "llama3.1:8b")

    t0 = time.time()
    state = load_extractor(use_llm=True, llm_provider=EXTRACTOR_PROVIDER, llm_model=EXTRACTOR_MODEL)
    print(f"[test] Extractor loaded in {time.time()-t0:.2f}s")

    all_ok = True

    for i, para in enumerate(TESTS, start=1):
        print("\n" + "-" * 60)
        print(f"TEST PARAGRAPH {i}")
        print(para)
        t0 = time.time()
        claims = extract_with_spans(state, para)
        elapsed = time.time() - t0
        print(f"Extracted {len(claims)} claims in {elapsed:.2f}s")

        for c in claims:
            print(f"  {c.id}. {c.text}")
            print(f"     source_text: {c.source_text}")
            # Assertion: substring matches
            try:
                assert para[c.start_offset:c.end_offset] == c.source_text, (
                    f"Offset mismatch for claim {c.id}: '{c.text}'"
                )
                print("     offset check: OK")
            except AssertionError as e:
                all_ok = False
                print("     offset check: FAIL ->", e)

    print("\n" + "=" * 70)
    if all_ok:
        print("PHASE 3: PASS")
        sys.exit(0)
    else:
        print("PHASE 3: FAIL")
        sys.exit(2)


if __name__ == "__main__":
    main()
