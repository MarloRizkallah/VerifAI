"""
test_phase2.py
==============
Phase 2 verification script. Run this from the backend/ directory on the lab machine
to confirm retriever.py and classifier.py work end-to-end before wiring them into
FastAPI lifespan.

Usage
-----
    cd /home/ai-ws2/Desktop/Marlo/GP_PROJ_FILES/verifai/backend
    python scripts/test_phase2.py

Expected output
---------------
For the claim "Albert Einstein was awarded the Nobel Prize in Physics":
  - retrieve() returns 5 Passage objects, top one from page "Albert_Einstein" or
    a related page ("Einstein's_awards_and_honors", etc.)
  - classify() on the top passage returns label="SUPPORTS" with high confidence

For the claim "The Eiffel Tower is located in Berlin, Germany":
  - retrieve() returns 5 Passage objects from Eiffel Tower / Paris-related pages
  - classify() on the top passage returns label="REFUTES" with reasonable confidence

If both expected outputs appear, Phase 2 is verified. Move on to Phase 3.

If load fails:
  - "Adapter directory not found" → check NLI_ADAPTER_PATHS in .env
  - "Qdrant dim mismatch" → wrong collection / wrong embedder
  - "Index file not found" → check BM25S_INDEX_PATH in .env
  - CUDA OOM → check what else is on GPU (nvidia-smi); the modules respect
    CUDA_VISIBLE_DEVICES at process launch.
"""

import os
import sys
import time
from pathlib import Path

# Make services/ importable when running from backend/
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services.retriever import load_retriever, retrieve  # noqa: E402
from services.classifier import load_classifier, classify, classify_batch  # noqa: E402


# ─────────────────────────────────────────────────────────────────────
# Read config from environment (mirrors what FastAPI lifespan will do)
# ─────────────────────────────────────────────────────────────────────

# Load .env if python-dotenv is available, otherwise rely on already-exported vars
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


def _env(key: str, default=None, required: bool = True):
    val = os.getenv(key, default)
    if required and val is None:
        sys.exit(f"FATAL: required env var {key} is not set (check .env)")
    return val


BM25S_INDEX_PATH = _env("BM25S_INDEX_PATH")
BM25S_IDS_PATH = _env("BM25S_IDS_PATH")
QDRANT_HOST = _env("QDRANT_HOST", "localhost")
QDRANT_PORT = int(_env("QDRANT_PORT", "6333"))
QDRANT_COLLECTION = _env("QDRANT_COLLECTION", "fever_wiki")

# Adapter paths: comma-separated list in .env, e.g.
# NLI_ADAPTER_PATHS=deberta_single_evidence_v2/adapter_seed_42,deberta_single_evidence_v2/adapter_seed_123,deberta_single_evidence_v2/adapter_seed_777
_adapter_paths_raw = _env("NLI_ADAPTER_PATHS")
NLI_ADAPTER_PATHS = [p.strip() for p in _adapter_paths_raw.split(",") if p.strip()]


# ─────────────────────────────────────────────────────────────────────
# Load
# ─────────────────────────────────────────────────────────────────────

print("=" * 70)
print("PHASE 2 VERIFICATION — loading retriever + classifier")
print("=" * 70)

t0 = time.time()
retriever_state = load_retriever(
    bm25_index_path=BM25S_INDEX_PATH,
    bm25_ids_path=BM25S_IDS_PATH,
    qdrant_host=QDRANT_HOST,
    qdrant_port=QDRANT_PORT,
    collection=QDRANT_COLLECTION,
)
print(f"\n[main] Retriever loaded in {time.time()-t0:.1f}s")

t0 = time.time()
classifier_state = load_classifier(adapter_paths=NLI_ADAPTER_PATHS)
print(f"[main] Classifier loaded in {time.time()-t0:.1f}s")


# ─────────────────────────────────────────────────────────────────────
# Test claims (mirror the notebook's smoke test for direct comparability)
# ─────────────────────────────────────────────────────────────────────

TEST_CLAIMS = [
    ("Albert Einstein was awarded the Nobel Prize in Physics in 1921.",
     "expect: SUPPORTS, factual"),
    ("The Eiffel Tower is located in Berlin, Germany.",
     "expect: REFUTES, hallucinated"),
]

print("\n" + "=" * 70)
print("RUNNING TEST CLAIMS")
print("=" * 70)

for claim, expected in TEST_CLAIMS:
    print(f"\n[{expected}]")
    print(f"  Claim: {claim}")

    # 1. Retrieve
    t0 = time.time()
    passages = retrieve(retriever_state, claim, top_k=5)
    t_ret = time.time() - t0
    print(f"  retrieve() → {len(passages)} passages in {t_ret:.2f}s")

    if not passages:
        print("  FAIL: no passages returned")
        continue

    for i, p in enumerate(passages, 1):
        print(
            f"    {i}. rerank={p.rerank_score:+.4f} sim={p.similarity:.4f} "
            f"{p.page_id[:50]}"
        )
        print(f"       {p.text[:100]}")

    # Confirm Passage fields look right
    top = passages[0]
    assert top.title == top.page_id.replace("_", " "), "title formatting wrong"
    assert top.url == f"https://en.wikipedia.org/wiki/{top.page_id}", "url wrong"
    assert 0.0 <= top.similarity <= 1.0, "similarity not in [0,1]"

    # 2. Classify top passage with single-pair API
    t0 = time.time()
    single = classify(classifier_state, claim, top.text)
    t_cls_single = time.time() - t0
    print(
        f"  classify(top) → {single['label']} "
        f"conf={single['confidence']:.2%} in {t_cls_single:.3f}s"
    )
    print(f"    probs: {single['probs']}")

    # 3. Classify ALL passages with batched API (should be much faster per-pair)
    t0 = time.time()
    batch = classify_batch(
        classifier_state, claim, [p.text for p in passages]
    )
    t_cls_batch = time.time() - t0
    print(
        f"  classify_batch(all 5) → {t_cls_batch:.3f}s total "
        f"({t_cls_batch/len(passages)*1000:.0f}ms/pair effective)"
    )
    for i, (p, r) in enumerate(zip(passages, batch), 1):
        print(
            f"    {i}. {r['label']:15s} conf={r['confidence']:.2%}  "
            f"sim={p.similarity:.3f}  {p.page_id[:40]}"
        )

    # Sanity: classify and classify_batch[0] should agree on label for the top passage
    assert single["label"] == batch[0]["label"], (
        f"classify vs classify_batch disagree on top passage: "
        f"{single['label']} vs {batch[0]['label']}"
    )

print("\n" + "=" * 70)
print("PHASE 2: PASS")
print("=" * 70)
print(
    "\nIf the labels match expectations and timings look reasonable "
    "(retrieve <2s, classify_batch <0.5s per claim), Phase 2 is verified. "
    "Continue to Phase 3."
)
