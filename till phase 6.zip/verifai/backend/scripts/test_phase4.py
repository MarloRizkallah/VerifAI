"""Test harness for Phase 4 explainer service.

Run as:
  CUDA_VISIBLE_DEVICES=1 /usr/bin/python3.10 scripts/test_phase4.py

Prints per-case outputs and runs graceful-degradation checks.
"""
import asyncio
import time
from statistics import mean

from services.explainer import load_explainer, explain


CASES = [
    (
        "Einstein won the Nobel Prize in 1922.",
        "Albert Einstein received the Nobel Prize in Physics in 1921 for his discovery of the law of the photoelectric effect.",
        "hallucinated",
        "should explain date mismatch",
    ),
    (
        "The Eiffel Tower is in Berlin.",
        "The Eiffel Tower is a wrought-iron lattice tower on the Champ de Mars in Paris, France.",
        "hallucinated",
        "should explain location mismatch",
    ),
    (
        "The Great Wall is visible from the Moon.",
        "Despite popular belief, the Great Wall of China is not easily visible from low Earth orbit without aid, let alone from the Moon.",
        "hallucinated",
        "should reference the evidence directly",
    ),
    (
        "Python was released in 1991.",
        "Python is a high-level programming language. Information about its release year is not present in this snippet.",
        "uncertain",
        "should acknowledge evidence does not confirm",
    ),
    (
        "Apple was founded in 1976.",
        "Apple Inc. was founded by Steve Jobs, Steve Wozniak, and Ronald Wayne on April 1, 1976.",
        "factual",
        "should return None — not called for factual",
    ),
]


def run_once(state, claim, evidence, verdict):
    t0 = time.perf_counter()
    try:
        out = asyncio.run(explain(state, claim, evidence, verdict))
    except Exception as e:
        out = f"EXCEPTION: {e}"
    latency_ms = (time.perf_counter() - t0) * 1000.0
    return out, latency_ms


def main():
    print("[test_phase4] Loading explainer state...")
    state = load_explainer()

    results = []
    print("\n=== Running cases ===\n")
    for claim, evidence, verdict, note in CASES:
        print("---")
        print(f"Claim: {claim}")
        print(f"Verdict: {verdict}  ({note})")
        out, ms = run_once(state, claim, evidence, verdict)
        print(f"Latency: {ms:.0f} ms")
        print("Output:\n", out)
        results.append((out, ms))

    # Graceful degradation tests
    print("\n=== Graceful degradation tests ===\n")
    try:
        o1, _ = run_once(state, "x", "", "hallucinated")
        print("Empty evidence ->", o1)
    except Exception as e:
        print("Empty evidence raised:", e)

    try:
        o2, _ = run_once(state, "", "some evidence", "hallucinated")
        print("Empty claim ->", o2)
    except Exception as e:
        print("Empty claim raised:", e)

    # Timeout path
    old_t = state.timeout_s
    try:
        state.timeout_s = 0.001
        o3, _ = run_once(state, CASES[0][0], CASES[0][1], CASES[0][2])
        print("Forced tiny timeout ->", o3)
    except Exception as e:
        print("Forced timeout raised:", e)
    finally:
        state.timeout_s = old_t

    # Summary
    str_returns = [r for r in results if isinstance(r[0], str) and r[0]]
    none_returns = [r for r in results if not (isinstance(r[0], str) and r[0])]
    print("\n=== Summary ===")
    print(f"Strings returned: {len(str_returns)}")
    print(f"None/empty/failed: {len(none_returns)}")
    if str_returns:
        print(f"Mean latency (ms) for string results: {mean([r[1] for r in str_returns]):.0f}")


if __name__ == "__main__":
    main()
