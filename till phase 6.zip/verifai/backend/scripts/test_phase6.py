"""Streaming SSE client for Phase 6 verification.

Run with:
  cd backend && PYTHONPATH=. /usr/bin/python3.10 scripts/test_phase6.py
"""

import asyncio
import json
import time

import httpx


async def main():
    payload = {"paragraph": "The Eiffel Tower is in Berlin. It was built in 1889."}
    print(f"[client] POST /verify with paragraph: {payload['paragraph']!r}")

    async with httpx.AsyncClient(timeout=60.0) as client:
        async with client.stream("POST", "http://localhost:8000/verify", json=payload) as response:
            print(f"[client] status={response.status_code} content-type={response.headers.get('content-type')}")
            t0 = time.perf_counter()
            async for line in response.aiter_lines():
                if not line.startswith("data:"):
                    continue
                event = json.loads(line[5:].strip())
                elapsed = time.perf_counter() - t0
                print(f"[{elapsed:5.2f}s] step={event['step']} status={event['status']}")
                if event.get("status") == "complete":
                    data = event["data"]
                    print(f"          claims_count={data['claims_count']} hallucination_rate={data['hallucination_rate']:.2f}")
                elif event.get("status") == "error":
                    print(f"          error={event['error']}")


if __name__ == "__main__":
    asyncio.run(main())
