"""End-to-end test for Phase 5 pipeline.

Run with:
  CUDA_VISIBLE_DEVICES=1 PYTHONPATH=. /usr/bin/python3.10 scripts/test_phase5.py
"""
import asyncio
import time

from config import (
    BM25S_INDEX_PATH,
    BM25S_IDS_PATH,
    QDRANT_HOST,
    QDRANT_PORT,
    QDRANT_COLLECTION,
    NLI_ADAPTER_PATHS,
    EXTRACTOR_PROVIDER,
    EXTRACTOR_MODEL,
)

from services.retriever import load_retriever
from services.classifier import load_classifier
from services.extractor import load_extractor
from services.explainer import load_explainer
from services.pipeline import verify_paragraph


TESTS = [
    (
        "Einstein/Apple",
        "Albert Einstein was born in 1879 in Germany and won the Nobel Prize in Physics in 1921. Apple was founded by Steve Jobs in 1976.",
    ),
    (
        "Eiffel/Berlin (hallucination)",
        "The Eiffel Tower is located in Berlin and was built in 1889. It is 330 metres tall.",
    ),
    (
        "Great Wall (mixed)",
        "The Great Wall of China was built by Emperor Qin Shi Huang in 200 BC. It is visible from the Moon with the naked eye.",
    ),
]


async def main():
    print("[load] retriever...")
    r = load_retriever(
        bm25_index_path=BM25S_INDEX_PATH,
        bm25_ids_path=BM25S_IDS_PATH,
        qdrant_host=QDRANT_HOST,
        qdrant_port=QDRANT_PORT,
        collection=QDRANT_COLLECTION,
    )

    print("[load] classifier...")
    c = load_classifier(adapter_paths=NLI_ADAPTER_PATHS)

    print("[load] extractor...")
    e = load_extractor(use_llm=True, llm_provider=EXTRACTOR_PROVIDER, llm_model=EXTRACTOR_MODEL)

    print("[load] explainer...")
    x = load_explainer()

    for name, paragraph in TESTS:
        print(f"\n=== {name} ===")
        t0 = time.time()
        try:
            out = await verify_paragraph(paragraph, r, c, e, x)
        except Exception as exc:
            print("Pipeline raised:", exc)
            continue
        dt = time.time() - t0
        print(f"Total time: {dt:.1f}s")
        print("claims_count:", out.get("claims_count"))
        print("hallucination_rate:", out.get("hallucination_rate"))
        print("verdicts:", out.get("verdicts"))
        for cl in out.get("claims", []):
            print(f"- id={cl['id']} verdict={cl['verdict']} conf={cl['confidence']} rel={cl['source_relevance']}")
            # Verify offsets
            st = paragraph[cl["start_offset"] : cl["end_offset"]]
            assert st == cl["source_text"], f"Offset mismatch for claim {cl['id']}"


if __name__ == "__main__":
    asyncio.run(main())
