# VerifAI Backend — Phase 1 Skeleton

FastAPI backend returning hardcoded mock data matching the locked API contract. This allows frontend development to proceed in parallel with Phase 2 ML implementation.

## Quick Start

```bash
cd verifai/backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Server starts on `http://localhost:8000`

## Endpoints

### `GET /health`
Health check endpoint.

**Response (200):**
```json
{"status": "ok"}
```

### `POST /verify`
Verify paragraph for hallucinations.

**Request:**
```json
{"paragraph": "Your text here"}
```

**Response (200):** Full mock response with 5 claims, matching the locked API contract.

**Validation:**
- Empty paragraph → HTTP 422, `INVALID_INPUT`
- Paragraph > 2000 chars → HTTP 422, `INVALID_INPUT`

## Mock Data

The `/verify` endpoint returns hardcoded mock data based on:

```
The Great Wall of China is the only man-made structure visible from space. 
It was built primarily during the Ming Dynasty but used standard industrial concrete in its construction. 
Recent archaeological studies suggest it spans over 13,171 miles including all trenches and barriers. 
The wall was originally conceived by Emperor Qin Shi Huang in the 3rd century BC.
```

Contains 5 claims with 2 factual, 2 hallucinated, 1 uncertain (hallucination_rate=0.4).

**Offsets are computed at runtime with assertions** — if any offset is incorrect, the request fails loudly during development.

## Configuration

All settings loaded from `.env` via `python-dotenv`:

- `HOST`, `PORT`, `ALLOWED_ORIGINS` — Server config
- `MAX_CHARS` — Paragraph length limit (2000)
- Retrieval/Model paths — Unused in Phase 1, populated for Phase 2+

## Project Structure

```
backend/
├── main.py              — FastAPI app, lifespan, CORS, routes
├── config.py            — Load .env, export constants
├── models/
│   ├── __init__.py
│   └── schemas.py       — Pydantic v2 models
├── routers/
│   ├── __init__.py
│   └── verify.py        — POST /verify with mock builder
├── services/
│   └── __init__.py      — Empty (populated Phase 2+)
├── requirements.txt
├── .env                 — Local copy (gitignored)
├── .env.example         — Template (committed)
└── .gitignore
```

## Next Phases

- **Phase 2:** Replace mock with real pipeline (Harrier embeddings → Qdrant → BM25 → reranker → DeBERTa NLI)
- **Phase 3:** Add claim extraction (LLM)
- **Phase 4:** Add explanations (LLM)
- **Phase 5:** Integrate with frontend
- **Phase 6:** Add SSE streaming
