"""
Configuration module — loads and exports all settings from .env
"""
""" 
import os
from dotenv import load_dotenv

# Load .env file
load_dotenv(override=True)

# Server
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", 8000))
ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "http://localhost:3000").split(",")

# Pipeline limits
MAX_CHARS = int(os.getenv("MAX_CHARS", 2000))

# Retrieval
QDRANT_HOST = os.getenv("QDRANT_HOST", "localhost")
QDRANT_PORT = int(os.getenv("QDRANT_PORT", 6333))
QDRANT_COLLECTION = os.getenv("QDRANT_COLLECTION", "fever_wiki_harrier")
BM25S_INDEX_PATH = os.getenv("BM25S_INDEX_PATH", "./indexes/bm25s_index")

# Models
DEBERTA_ADAPTER_DIR = os.getenv("DEBERTA_ADAPTER_DIR", "./models/deberta_single_evidence_v2")
HARRIER_MODEL = os.getenv("HARRIER_MODEL", "microsoft/harrier-oss-v1-270m")
RERANKER_MODEL = os.getenv("RERANKER_MODEL", "Alibaba-NLP/gte-reranker-modernbert-base")

# LLM backends
EXTRACTOR_PROVIDER = os.getenv("EXTRACTOR_PROVIDER", "ollama")
EXTRACTOR_MODEL = os.getenv("EXTRACTOR_MODEL", "llama3.1:8b")
EXPLAINER_PROVIDER = os.getenv("EXPLAINER_PROVIDER", "ollama")
EXPLAINER_MODEL = os.getenv("EXPLAINER_MODEL", "llama3.1:8b")
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434/v1")

# Retriever
BM25S_INDEX_PATH = os.getenv("BM25S_INDEX_PATH")
BM25S_IDS_PATH = os.getenv("BM25S_IDS_PATH")
QDRANT_HOST = os.getenv("QDRANT_HOST", "localhost")
QDRANT_PORT = int(os.getenv("QDRANT_PORT", "6333"))
QDRANT_COLLECTION = os.getenv("QDRANT_COLLECTION", "fever_wiki")

# Classifier
NLI_ADAPTER_PATHS = [
	p.strip() for p in os.getenv("NLI_ADAPTER_PATHS", "").split(",") if p.strip()
]
"""
"""
Configuration module — loads and exports all settings from .env
"""

import os
from dotenv import load_dotenv

load_dotenv(override=True)

# Server
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", 8000))
ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "http://localhost:3000").split(",")

# Pipeline limits
MAX_CHARS = int(os.getenv("MAX_CHARS", 2000))

# Retriever (Phase 2)
BM25S_INDEX_PATH  = os.getenv("BM25S_INDEX_PATH")
BM25S_IDS_PATH    = os.getenv("BM25S_IDS_PATH")
QDRANT_HOST       = os.getenv("QDRANT_HOST", "localhost")
QDRANT_PORT       = int(os.getenv("QDRANT_PORT", "6333"))
QDRANT_COLLECTION = os.getenv("QDRANT_COLLECTION", "fever_wiki")

# Classifier (Phase 2)
NLI_ADAPTER_PATHS = [
    p.strip() for p in os.getenv("NLI_ADAPTER_PATHS", "").split(",") if p.strip()
]

# LLM backends (Phase 3/4 — extractor + explainer)
EXTRACTOR_PROVIDER = os.getenv("EXTRACTOR_PROVIDER", "ollama")
EXTRACTOR_MODEL    = os.getenv("EXTRACTOR_MODEL", "llama3.1:8b")
EXPLAINER_PROVIDER = os.getenv("EXPLAINER_PROVIDER", "ollama")
EXPLAINER_MODEL    = os.getenv("EXPLAINER_MODEL", "llama3.1:8b")
OLLAMA_BASE_URL    = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434/v1")
# Explainer timeout (seconds)
EXPLAINER_TIMEOUT_S = float(os.getenv("EXPLAINER_TIMEOUT_S", "15.0"))