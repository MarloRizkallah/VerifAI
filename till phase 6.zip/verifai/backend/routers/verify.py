"""
Verify endpoint — returns mock data matching the locked API contract
"""

import json

from fastapi import APIRouter, HTTPException, Request
from sse_starlette.sse import EventSourceResponse
from models.schemas import (
    VerifyRequest,
    VerifyResponse,
    ErrorResponse,
    Claim,
    Evidence,
    Verdicts,
)
from config import MAX_CHARS
from services.pipeline import (
    verify_paragraph_streaming,
    NoClaimsFound,
    RetrievalFailure,
    ClassificationFailure,
    PipelineError,
)

router = APIRouter()

# Reference paragraph used for offset calculation
REFERENCE_PARAGRAPH = (
    "The Great Wall of China is the only man-made structure visible from space. "
    "It was built primarily during the Ming Dynasty but used standard industrial concrete in its construction. "
    "Recent archaeological studies suggest it spans over 13,171 miles including all trenches and barriers. "
    "The wall was originally conceived by Emperor Qin Shi Huang in the 3rd century BC."
)


def build_mock_response() -> VerifyResponse:
    """
    Builds the hardcoded mock response with 5 claims.
    Uses REFERENCE_PARAGRAPH for offset calculation with runtime assertions.
    """

    # Compute offsets using REFERENCE_PARAGRAPH
    def get_offsets(source_text: str):
        start = REFERENCE_PARAGRAPH.find(source_text)
        if start == -1:
            raise ValueError(f"Source text not found in reference paragraph: {source_text}")
        end = start + len(source_text)
        
        # Runtime assertion: verify the offset is correct
        assert REFERENCE_PARAGRAPH[start:end] == source_text, (
            f"Offset mismatch for '{source_text[:30]}...': "
            f"ref[{start}:{end}] = '{REFERENCE_PARAGRAPH[start:end][:50]}...'"
        )
        
        return start, end

    # Claim 1
    source_text_1 = "The Great Wall of China is the only man-made structure visible from space."
    start_1, end_1 = get_offsets(source_text_1)
    claim_1 = Claim(
        id=1,
        text="The Great Wall of China is visible from space.",
        source_text=source_text_1,
        start_offset=start_1,
        end_offset=end_1,
        verdict="hallucinated",
        confidence=0.94,
        source_relevance=0.82,
        explanation=(
            "The claim states the Wall is visible from space, but NASA and multiple astronauts "
            "have stated it is not visible to the naked eye from low Earth orbit. This common myth "
            "has been repeatedly debunked."
        ),
        evidence=Evidence(
            snippet=(
                "NASA and astronauts have confirmed that the Great Wall is generally not visible to the "
                "naked eye from low Earth orbit, and certainly not from the Moon."
            ),
            article_title="Great Wall of China",
            article_url="https://en.wikipedia.org/wiki/Great_Wall_of_China",
        ),
    )

    # Claim 2
    source_text_2 = "It was built primarily during the Ming Dynasty"
    start_2, end_2 = get_offsets(source_text_2)
    claim_2 = Claim(
        id=2,
        text="The Great Wall of China was built primarily during the Ming Dynasty.",
        source_text=source_text_2,
        start_offset=start_2,
        end_offset=end_2,
        verdict="factual",
        confidence=0.99,
        source_relevance=0.91,
        explanation=None,
        evidence=Evidence(
            snippet=(
                "The Ming Great Wall is the most famous part of the system, constructed during the "
                "Ming dynasty with durable materials like bricks and stone."
            ),
            article_title="Great Wall of China",
            article_url="https://en.wikipedia.org/wiki/Great_Wall_of_China",
        ),
    )

    # Claim 3
    source_text_3 = "but used standard industrial concrete in its construction"
    start_3, end_3 = get_offsets(source_text_3)
    claim_3 = Claim(
        id=3,
        text="The Great Wall of China used standard industrial concrete in its construction.",
        source_text=source_text_3,
        start_offset=start_3,
        end_offset=end_3,
        verdict="hallucinated",
        confidence=0.91,
        source_relevance=0.78,
        explanation=(
            "The claim that industrial concrete was used is historically impossible — "
            "industrial concrete was developed in the 19th century, long after the Wall's "
            "main construction periods."
        ),
        evidence=Evidence(
            snippet=(
                "The Ming Wall was built with bricks, stone, tamped earth, and other traditional materials. "
                "Industrial concrete was not invented until the 19th century."
            ),
            article_title="Great Wall of China",
            article_url="https://en.wikipedia.org/wiki/Great_Wall_of_China",
        ),
    )

    # Claim 4
    source_text_4 = "Recent archaeological studies suggest it spans over 13,171 miles including all trenches and barriers"
    start_4, end_4 = get_offsets(source_text_4)
    claim_4 = Claim(
        id=4,
        text="The Great Wall of China spans over 13,171 miles.",
        source_text=source_text_4,
        start_offset=start_4,
        end_offset=end_4,
        verdict="uncertain",
        confidence=0.42,
        source_relevance=0.65,
        explanation=(
            "The figure appears in one 2012 survey but other estimates vary significantly depending on "
            "whether trenches and natural barriers are counted. The classifier could not confidently "
            "support or refute the claim."
        ),
        evidence=Evidence(
            snippet=(
                "A 2012 archaeological survey reported a total length of approximately 21,196 kilometers "
                "(13,171 miles) including all branches, trenches, and natural barriers."
            ),
            article_title="Great Wall of China",
            article_url="https://en.wikipedia.org/wiki/Great_Wall_of_China",
        ),
    )

    # Claim 5
    source_text_5 = "The wall was originally conceived by Emperor Qin Shi Huang in the 3rd century BC"
    start_5, end_5 = get_offsets(source_text_5)
    claim_5 = Claim(
        id=5,
        text="Emperor Qin Shi Huang originally conceived the Great Wall of China.",
        source_text=source_text_5,
        start_offset=start_5,
        end_offset=end_5,
        verdict="factual",
        confidence=0.97,
        source_relevance=0.88,
        explanation=None,
        evidence=Evidence(
            snippet=(
                "The first emperor of unified China, Qin Shi Huang, ordered the connection of "
                "pre-existing fortifications into a single defensive line in the 3rd century BC."
            ),
            article_title="Great Wall of China",
            article_url="https://en.wikipedia.org/wiki/Great_Wall_of_China",
        ),
    )

    # Aggregate verdicts
    claims = [claim_1, claim_2, claim_3, claim_4, claim_5]
    verdicts = Verdicts(
        factual=sum(1 for c in claims if c.verdict == "factual"),
        hallucinated=sum(1 for c in claims if c.verdict == "hallucinated"),
        uncertain=sum(1 for c in claims if c.verdict == "uncertain"),
    )

    hallucination_rate = verdicts.hallucinated / len(claims)

    return VerifyResponse(
        claims_count=len(claims),
        hallucination_rate=hallucination_rate,
        verdicts=verdicts,
        claims=claims,
    )


@router.post("/verify")
async def verify(request: VerifyRequest, req: Request):
    """
    Verify paragraph for hallucinations.

    Validation:
    - Paragraph cannot be empty
    - Paragraph cannot exceed MAX_CHARS characters

    Returns mock response with 5 claims (Phase 1).
    """

    # Validate: empty paragraph
    if not request.paragraph.strip():
        raise HTTPException(
            status_code=422,
            detail={
                "error": True,
                "code": "INVALID_INPUT",
                "message": "Paragraph cannot be empty",
            },
        )

    # Validate: max length
    if len(request.paragraph) > MAX_CHARS:
        raise HTTPException(
            status_code=422,
            detail={
                "error": True,
                "code": "INVALID_INPUT",
                "message": f"Paragraph exceeds maximum length of {MAX_CHARS} characters",
            },
        )

    async def event_stream():
        async for event in verify_paragraph_streaming(
            request.paragraph,
            req.app.state.retriever,
            req.app.state.classifier,
            req.app.state.extractor,
            req.app.state.explainer,
        ):
            yield {"data": json.dumps(event)}

    return EventSourceResponse(event_stream())
