from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional
import time
import re
from services.claim_extractor import ClaimExtractor, load_spacy

@dataclass
class Claim:
    id: int
    text: str
    source_text: str
    start_offset: int
    end_offset: int


@dataclass
class ExtractorState:
    extractor: object
    nlp: Optional[object]


def load_extractor(
    use_llm: bool = True,
    llm_provider: str = "ollama",
    llm_model: str = "llama3.1:8b",
) -> ExtractorState:
    """Load spaCy + instantiate ClaimExtractor. Call once at FastAPI startup."""
    # Load spaCy via the helper in claim_extractor (prints helpful message)
    nlp = load_spacy()
    extractor = ClaimExtractor(use_llm=use_llm, llm_provider=llm_provider, llm_model=llm_model)
    return ExtractorState(extractor=extractor, nlp=nlp)


def _split_sentences_with_offsets(nlp, paragraph: str):
    """Return list of (text, start_char, end_char) sentence tuples.

    If `nlp` is None, fall back to a regex-based splitter that also
    computes offsets.
    """
    if nlp:
        doc = nlp(paragraph)
        return [(s.text, s.start_char, s.end_char) for s in doc.sents if s.text.strip()]

    # Fallback: find sentence boundaries using simple regex and compute offsets
    spans = []
    # matches end punctuation followed by space(s). Keep sentence terminator.
    parts = re.finditer(r'.+?(?:[.!?](?:\s|$)|$)', paragraph, flags=re.DOTALL)
    for m in parts:
        txt = m.group(0).strip()
        if not txt:
            continue
        start = m.start()
        end = m.end()
        spans.append((txt, start, end))
    return spans


def _jaccard(a: str, b: str) -> float:
    sa = set(a.lower().split())
    sb = set(b.lower().split())
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def extract_with_spans(state: ExtractorState, paragraph: str) -> List[Claim]:
    """Extract atomic claims and attribute each to its parent sentence.

    See Phase 3 spec for attribution algorithm.
    """
    paragraph = paragraph or ""
    sentences = _split_sentences_with_offsets(state.nlp, paragraph)

    # Build sentence list for jaccard matching
    sent_texts = [s[0] for s in sentences]
    sent_offsets = [(s[1], s[2]) for s in sentences]

    # Extract atomic claims using the ClaimExtractor
    claims = state.extractor.extract(paragraph)

    assigned = []  # tuples (claim_text, sent_idx)

    # Precompute longest sentence index for fallback
    if sentences:
        longest_idx = max(range(len(sentences)), key=lambda i: len(sentences[i][0]))
    else:
        longest_idx = None

    for claim in claims:
        # Find best matching sentence by Jaccard
        best_idx = None
        best_score = 0.0
        for i, s in enumerate(sent_texts):
            score = _jaccard(claim, s)
            if score > best_score:
                best_score = score
                best_idx = i

        if best_score < 0.05 or best_idx is None:
            # fallback to longest sentence
            if longest_idx is not None:
                print(f"[extractor] WARNING: low Jaccard fallback for claim: {claim!r}")
                best_idx = longest_idx
            else:
                # No sentences at all — attribute to whole paragraph
                best_idx = None

        assigned.append((claim, best_idx))

    # Build Claim objects with offsets; if no sentences, use full paragraph
    out: List[Claim] = []
    for claim_text, idx in assigned:
        if idx is None:
            src_text = paragraph
            start, end = 0, len(paragraph)
        else:
            src_text = sentences[idx][0]
            start, end = sentences[idx][1], sentences[idx][2]

        out.append(Claim(id=0, text=claim_text, source_text=src_text, start_offset=start, end_offset=end))

    # Order by start_offset ascending and assign 1-indexed ids
    out_sorted = sorted(out, key=lambda c: c.start_offset)
    for i, c in enumerate(out_sorted, start=1):
        c.id = i

    return out_sorted
