"""
classifier.py
=============
DeBERTa-v3-large + LoRA NLI ensemble (3 seeds: 42, 123, 777).

Ported from RAG_v2_Harrier.ipynb Steps 6A-6B. Logic unchanged; module-level
globals (nli_models, nli_tokenizer) refactored into a ClassifierState that is
built once at startup and passed explicitly to inference functions.

NOTE: This module ONLY does NLI classification. The 5-case verdict logic
(SUPPORTS/REFUTES/NEI → factual/hallucinated/uncertain/...) lives in
pipeline.py (Phase 5), per the build plan.

Public API
----------
load_classifier(...) -> ClassifierState
    Loads base model + 3 adapters. Call once at FastAPI startup.

classify_batch(state, claim, passages) -> list[dict]
    PRIMARY API. Classifies N (claim, passage_i) pairs in one batched forward
    per adapter — 3 model forwards total, not 3*N. Preserves the ~100x speedup
    from the notebook's batched ensemble.

classify(state, claim, passage) -> dict
    Convenience wrapper for one pair. Internally calls classify_batch.
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import List

import numpy as np
import torch
from peft import PeftModel
from transformers import AutoModelForSequenceClassification, AutoTokenizer


# ─────────────────────────────────────────────────────────────────────
# Constants (must match training-time LABEL2ID exactly)
# ─────────────────────────────────────────────────────────────────────

NLI_LABEL2ID = {"SUPPORTS": 0, "REFUTES": 1, "NOT ENOUGH INFO": 2}
NLI_ID2LABEL = {v: k for k, v in NLI_LABEL2ID.items()}
NLI_NUM_LABELS = len(NLI_LABEL2ID)


# ─────────────────────────────────────────────────────────────────────
# State
# ─────────────────────────────────────────────────────────────────────

@dataclass
class ClassifierState:
    tokenizer: object
    models: list             # list of 3 PeftModel instances on `device`
    device: torch.device
    max_len: int


# ─────────────────────────────────────────────────────────────────────
# Loader (call once at startup)
# ─────────────────────────────────────────────────────────────────────

def load_classifier(
    adapter_paths: List[str],
    base_model_id: str = "microsoft/deberta-v3-large",
    max_len: int = 256,
) -> ClassifierState:
    """
    Load DeBERTa-v3-large base + 3 LoRA adapters. ~15s on warm cache.

    Notes
    -----
    - weights_only=False on both AutoModel and PeftModel: torch < 2.6 doesn't
      have safetensors-by-default for these paths; the adapters are trusted
      local artifacts (deberta_single_evidence_v2/) so the safety check is moot.
    - One fresh base model is instantiated per adapter (PeftModel constraint).
      This means VRAM = ~3x DeBERTa-v3-large base + 3x tiny LoRA. On a 16.7 GB
      RTX 5000 with Harrier + reranker also resident, this is ~7 GB total —
      tight but workable.
    - modules_to_save=["classifier", "pooler"] is baked into each adapter's
      saved config, so the loaded PeftModel correctly restores both the LoRA
      params AND the trained classifier/pooler heads. Do not strip them.
    """
    # Validate adapter dirs before any heavy lifting
    for p in adapter_paths:
        if not os.path.isdir(p):
            raise FileNotFoundError(
                f"Adapter directory not found: {p!r} — "
                f"confirm deberta_single_evidence_v2/ exists and the path "
                f"in .env is correct."
            )
    print(
        f"[classifier] Adapter dirs: "
        f"{[os.path.basename(p) for p in adapter_paths]} — all found"
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"[classifier] Loading NLI tokenizer ({base_model_id}) ...")
    tokenizer = AutoTokenizer.from_pretrained(base_model_id)

    print(f"[classifier] Loading {len(adapter_paths)} adapter(s) ...")
    models = []
    for p in adapter_paths:
        t0 = time.time()
        base = AutoModelForSequenceClassification.from_pretrained(
            base_model_id,
            num_labels=NLI_NUM_LABELS,
            id2label=NLI_ID2LABEL,
            label2id=NLI_LABEL2ID,
            ignore_mismatched_sizes=True,
            weights_only=False,  # torch < 2.6
        )
        m = PeftModel.from_pretrained(base, p, weights_only=False).to(device).eval()
        models.append(m)
        if torch.cuda.is_available():
            vram = torch.cuda.memory_allocated() / 1024**2
            print(
                f"[classifier]   {os.path.basename(p)} | "
                f"{time.time()-t0:.1f}s | VRAM {vram:.0f} MB"
            )
        else:
            print(f"[classifier]   {os.path.basename(p)} | {time.time()-t0:.1f}s | CPU")

    return ClassifierState(
        tokenizer=tokenizer,
        models=models,
        device=device,
        max_len=max_len,
    )


# ─────────────────────────────────────────────────────────────────────
# Inference (primary: batched; convenience: single-pair)
# ─────────────────────────────────────────────────────────────────────

@torch.no_grad()
def classify_batch(
    state: ClassifierState, claim: str, passages: List[str]
) -> List[dict]:
    """
    Classify N (claim, passage_i) pairs in one batched forward per model.

    Logits are averaged across the 3 adapters BEFORE softmax — NOT probability
    averaging — to preserve calibration under disagreement.

    Cost: 3 model forwards total, regardless of N. Roughly 100x faster than
    calling classify() N times (per the notebook smoke-test timings).

    Returns
    -------
    list of N dicts, one per input passage:
        {
            "label":      "SUPPORTS" | "REFUTES" | "NOT ENOUGH INFO",
            "confidence": float (max softmax prob),
            "probs":      {"SUPPORTS": float, "REFUTES": float, "NOT ENOUGH INFO": float}
        }
    Returns [] if passages is empty.
    """
    if not passages:
        return []

    enc = state.tokenizer(
        [claim.strip()] * len(passages),
        [p.strip() for p in passages],
        max_length=state.max_len,
        padding=True,
        truncation=True,
        return_tensors="pt",
    )
    enc = {k: v.to(state.device) for k, v in enc.items()}

    # [3, N, 3] → mean over adapters → [N, 3] → softmax
    all_logits = torch.stack(
        [m(**enc).logits for m in state.models], dim=0
    )
    avg_logits = all_logits.mean(dim=0)
    probs_mat = torch.softmax(avg_logits, dim=-1).cpu().numpy()  # [N, 3]

    results: List[dict] = []
    for row in probs_mat:
        pred_id = int(np.argmax(row))
        results.append({
            "label": NLI_ID2LABEL[pred_id],
            "confidence": round(float(row[pred_id]), 4),
            "probs": {
                NLI_ID2LABEL[i]: round(float(row[i]), 4)
                for i in range(NLI_NUM_LABELS)
            },
        })
    return results


def classify(state: ClassifierState, claim: str, passage: str) -> dict:
    """Convenience wrapper for a single (claim, passage) pair. Prefer
    classify_batch when classifying multiple passages for the same claim."""
    return classify_batch(state, claim, [passage])[0]
