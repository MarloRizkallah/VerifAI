from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass
from typing import Optional

from openai import OpenAI

from config import EXPLAINER_PROVIDER, EXPLAINER_MODEL, EXPLAINER_TIMEOUT_S, OLLAMA_BASE_URL


@dataclass
class ExplainerState:
    client: OpenAI
    model: str
    timeout_s: float


def load_explainer() -> ExplainerState:
    """Create an ExplainerState pointing at Ollama (OpenAI-compatible API).

    Raises
    ------
    ValueError
        If EXPLAINER_PROVIDER is not 'ollama'.
    """
    if EXPLAINER_PROVIDER.lower() != "ollama":
        raise ValueError(
            f"Unsupported explainer provider: {EXPLAINER_PROVIDER!r}. "
            "Only 'ollama' is supported in Phase 4."
        )

    client = OpenAI(api_key="ollama", base_url=OLLAMA_BASE_URL)
    state = ExplainerState(
        client=client,
        model=EXPLAINER_MODEL,
        timeout_s=float(EXPLAINER_TIMEOUT_S),
    )
    print(f"[explainer] Loaded explainer model {state.model} (timeout {state.timeout_s}s)")
    return state


async def explain(
    state: ExplainerState,
    claim: str,
    evidence_snippet: str,
    verdict: str,
) -> Optional[str]:
    """Return a short explanation string or None.

    Behavior per Phase 4 spec: only call for 'hallucinated' or 'uncertain'.
    Any exception or sanity-fail returns None and logs a warning.
    """
    # Only call for relevant verdicts
    if verdict not in ("hallucinated", "uncertain"):
        return None
    if not claim.strip() or not evidence_snippet.strip():
        return None
    system_prompt = (
        "You are a fact-checking assistant. You explain why a claim was given "
        "a particular verdict, based strictly on the Wikipedia evidence provided. "
        "You do not introduce outside knowledge. You write 2–3 plain sentences."
    )

    user_prompt = (
        f"Claim: {claim}\n\n"
        f"Wikipedia evidence: {evidence_snippet}\n\n"
        f"Verdict: {verdict}\n\n"
        "In 2–3 plain sentences, explain why this verdict was reached. "
        "Base your explanation ONLY on the evidence snippet above. "
        "Do not introduce outside information."
    )

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]

    try:
        t0 = time.perf_counter()

        def _call():
            return state.client.chat.completions.create(
                model=state.model,
                messages=messages,
                temperature=0.0,
                max_tokens=200,
                timeout=state.timeout_s,
            )

        resp = await asyncio.to_thread(_call)
        latency_ms = (time.perf_counter() - t0) * 1000.0

        content = resp.choices[0].message.content
        if content is None:
            logging.warning("[explainer] empty response from explainer")
            return None

        text = content.strip()
        if not text or len(text) < 20 or len(text) > 800:
            logging.warning(
                f"[explainer] response failed length checks (len={len(text) if text else 0})"
            )
            return None

        logging.info(f"[explainer] explain() succeeded in {latency_ms:.0f}ms")
        return text

    except Exception as e:
        logging.warning(f"[explainer] explain() failed: {e}")
        return None