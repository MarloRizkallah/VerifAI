"""
retriever.py
============
Hybrid retrieval pipeline: BM25s sparse + Harrier dense + RRF fusion + gte-reranker.

Ported from RAG_v2_Harrier.ipynb Steps 5A-5F. The underlying logic is unchanged;
only the variable plumbing has been refactored from module-level globals into a
RetrieverState dataclass that is built once at startup and passed explicitly to
every inference function.

Public API
----------
load_retriever(...) -> RetrieverState
    Builds the state object. Call once at FastAPI startup (in the lifespan).

retrieve(state, claim, top_k=5) -> list[Passage]
    Full hybrid pipeline for one claim. Returns reranked top_k passages.

Passage
    Dataclass holding passage_id, page_id, sentence_id, text, title, url,
    rerank_score, similarity. Used downstream by pipeline.py (Phase 5).
"""

from __future__ import annotations

import math
import pickle
import time
from dataclasses import dataclass
from typing import List, Tuple

import bm25s
import numpy as np
import torch
import torch.nn.functional as F
from qdrant_client import QdrantClient
from transformers import (
    AutoModel,
    AutoModelForSequenceClassification,
    AutoTokenizer,
)


# ─────────────────────────────────────────────────────────────────────
# Data classes
# ─────────────────────────────────────────────────────────────────────

@dataclass
class Passage:
    """One reranked passage. Used downstream by the pipeline + API response."""
    passage_id: str        # "Albert_Einstein::5"
    page_id: str           # "Albert_Einstein"
    sentence_id: str       # "5"
    text: str              # the passage text itself
    title: str             # "Albert Einstein" (page_id with underscores → spaces)
    url: str               # "https://en.wikipedia.org/wiki/Albert_Einstein"
    rerank_score: float    # raw cross-encoder logit, can be negative
    similarity: float      # sigmoid(rerank_score), in [0, 1] — used by 5-case verdict


@dataclass
class RetrieverState:
    """All loaded models, indices, and config. Built by load_retriever(), passed
    to retrieve(). Lives on app.state.retriever for the FastAPI process lifetime.
    """
    # Indices
    bm25_retriever: object          # bm25s.BM25 instance
    passage_ids: list               # str list; position i ↔ Qdrant point id i
    pid_to_qid: dict                # passage_id → integer Qdrant point id
    qdrant_client: QdrantClient

    # Embedder (Harrier)
    embed_tokenizer: object
    embed_model: object

    # Reranker (gte-reranker-modernbert-base)
    reranker_tokenizer: object
    reranker_model: object

    # Config (carried through so inference fns don't reach into globals)
    device: torch.device
    collection: str
    query_prefix: str
    embed_max_len: int
    reranker_batch: int
    reranker_max_len: int


# ─────────────────────────────────────────────────────────────────────
# Loader (call once at startup)
# ─────────────────────────────────────────────────────────────────────

def load_retriever(
    bm25_index_path: str,
    bm25_ids_path: str,
    qdrant_host: str,
    qdrant_port: int,
    collection: str,
    embed_model_id: str = "microsoft/harrier-oss-v1-270m",
    embed_max_len: int = 256,
    embed_dtype: torch.dtype = torch.float32,
    query_prefix: str = (
        "Instruct: Given a claim, retrieve evidence passages "
        "that support or refute it\nQuery: "
    ),
    reranker_model_id: str = "Alibaba-NLP/gte-reranker-modernbert-base",
    reranker_batch: int = 32,
    reranker_max_len: int = 512,
    qdrant_timeout: int = 120,
) -> RetrieverState:
    """
    Load BM25s index (mmap), connect Qdrant, load Harrier embedder, load reranker.

    Device is read from torch.cuda.is_available() — respects whatever
    CUDA_VISIBLE_DEVICES the FastAPI process was launched with. No hardcoded GPU.

    Notes
    -----
    - Harrier requires FP32 on Turing (CC 7.5 / RTX 5000) — FP16 produces NaN.
    - attn_implementation="sdpa" matches the notebook; required for Harrier.
    - Qdrant timeout=120 (httpx socket-read) is the lab-tested value;
      shorter values cause ReadTimeout under load.
    - The pid_to_qid lookup assumes Qdrant point IDs are sequential integers
      matching iter_passages order (passage_ids[i] == Qdrant point i).
      This invariant is established by the embed+upsert path in Step 4C.
    """
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 1. BM25s index (mmap=True is fast and keeps RAM low)
    print(f"[retriever] Loading bm25s index from {bm25_index_path} (mmap=True) ...")
    t0 = time.time()
    bm25_retriever = bm25s.BM25.load(bm25_index_path, mmap=True)
    with open(bm25_ids_path, "rb") as f:
        passage_ids = pickle.load(f)
    print(f"[retriever]   {len(passage_ids):,} passages | {time.time()-t0:.1f}s")

    # 2. passage_id → Qdrant integer point id
    print("[retriever] Building pid_to_qid lookup ...")
    pid_to_qid = {pid: i for i, pid in enumerate(passage_ids)}

    # 3. Qdrant
    print(f"[retriever] Connecting to Qdrant {qdrant_host}:{qdrant_port} ...")
    qdrant_client = QdrantClient(
        host=qdrant_host, port=qdrant_port, timeout=qdrant_timeout
    )
    info = qdrant_client.get_collection(collection)
    point_count = qdrant_client.count(collection).count
    print(
        f"[retriever]   collection={collection} "
        f"dim={info.config.params.vectors.size} "
        f"status={info.status} points={point_count:,}"
    )
    assert info.config.params.vectors.size == 640, (
        f"Qdrant dim {info.config.params.vectors.size} != Harrier dim 640. "
        f"Did Step 3/4 use a different embedder?"
    )

    # 4. Harrier embedder
    print(f"[retriever] Loading Harrier {embed_model_id} ...")
    t0 = time.time()
    embed_tokenizer = AutoTokenizer.from_pretrained(embed_model_id)
    embed_model = AutoModel.from_pretrained(
        embed_model_id,
        torch_dtype=embed_dtype,
        attn_implementation="sdpa",
    ).to(device).eval()
    if torch.cuda.is_available():
        vram = torch.cuda.memory_allocated() / 1024**2
        print(f"[retriever]   {time.time()-t0:.1f}s | VRAM {vram:.0f} MB")
    else:
        print(f"[retriever]   {time.time()-t0:.1f}s | CPU")

    # 5. Reranker
    print(f"[retriever] Loading reranker {reranker_model_id} ...")
    t0 = time.time()
    reranker_tokenizer = AutoTokenizer.from_pretrained(reranker_model_id)
    reranker_model = AutoModelForSequenceClassification.from_pretrained(
        reranker_model_id,
        torch_dtype=torch.float32,
    ).to(device).eval()
    if torch.cuda.is_available():
        vram = torch.cuda.memory_allocated() / 1024**2
        print(f"[retriever]   {time.time()-t0:.1f}s | VRAM {vram:.0f} MB")
    else:
        print(f"[retriever]   {time.time()-t0:.1f}s | CPU")

    return RetrieverState(
        bm25_retriever=bm25_retriever,
        passage_ids=passage_ids,
        pid_to_qid=pid_to_qid,
        qdrant_client=qdrant_client,
        embed_tokenizer=embed_tokenizer,
        embed_model=embed_model,
        reranker_tokenizer=reranker_tokenizer,
        reranker_model=reranker_model,
        device=device,
        collection=collection,
        query_prefix=query_prefix,
        embed_max_len=embed_max_len,
        reranker_batch=reranker_batch,
        reranker_max_len=reranker_max_len,
    )


# ─────────────────────────────────────────────────────────────────────
# Internal helpers (ported verbatim from notebook, refactored to take state)
# ─────────────────────────────────────────────────────────────────────

def _last_token_pool(hidden: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    """Last non-padding token pool. Required by Harrier (decoder-only backbone)."""
    left_pad = mask[:, -1].sum() == mask.shape[0]
    if left_pad:
        return hidden[:, -1]
    seq_lens = mask.sum(dim=1) - 1
    return hidden[torch.arange(hidden.size(0), device=hidden.device), seq_lens]


@torch.no_grad()
def _harrier_encode(
    state: RetrieverState, texts: List[str], prefix: str = ""
) -> np.ndarray:
    """L2-normed float32 (N, 640). prefix='' for documents, query_prefix for claims."""
    if prefix:
        texts = [prefix + t for t in texts]
    tok = state.embed_tokenizer(
        texts,
        max_length=state.embed_max_len,
        padding=True,
        truncation=True,
        return_tensors="pt",
    ).to(state.device)
    out = state.embed_model(**tok)
    vecs = _last_token_pool(out.last_hidden_state, tok["attention_mask"])
    return F.normalize(vecs, p=2, dim=-1).cpu().float().numpy()


def _bm25_search(
    state: RetrieverState, claim: str, k: int = 10
) -> List[Tuple[str, float]]:
    """Top-k (passage_id, score), descending. Uses bm25s (Day 4 Track A backend)."""
    q_tokens = bm25s.tokenize([claim], stopwords=None, stemmer=None)
    results, scores = state.bm25_retriever.retrieve(q_tokens, k=k)
    doc_ids = results[0]
    doc_scores = scores[0]
    return [
        (state.passage_ids[int(doc_ids[i])], float(doc_scores[i]))
        for i in range(len(doc_ids))
    ]


def _dense_search(
    state: RetrieverState, claim: str, k: int = 10
) -> List[Tuple[str, float]]:
    """Top-k (passage_id, cosine_score), descending."""
    status = str(state.qdrant_client.get_collection(state.collection).status).lower()
    if not status.endswith("green"):
        print(
            f"[retriever] WARNING: Qdrant status={status} — "
            f"using brute-force scan (results correct, slower)"
        )
    vec = _harrier_encode(state, [claim], prefix=state.query_prefix)[0].tolist()
    hits = state.qdrant_client.query_points(
        collection_name=state.collection,
        query=vec,
        limit=k,
        with_payload=True,
    ).points
    return [(h.payload["passage_id"], h.score) for h in hits]


def _reciprocal_rank_fusion(
    rankings: List[List[Tuple[str, float]]], k: int = 60
) -> List[Tuple[str, float]]:
    """RRF: score(d) = sum_i 1/(k + rank_i(d)). Default k=60 (Cormack et al. 2009)."""
    scores: dict = {}
    for ranking in rankings:
        for rank, (pid, _) in enumerate(ranking, start=1):
            scores[pid] = scores.get(pid, 0.0) + 1.0 / (k + rank)
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)


@torch.no_grad()
def _rerank(
    state: RetrieverState, claim: str, passages: List[str]
) -> List[float]:
    """Cross-encoder rerank. Returns one float per passage; higher = more relevant."""
    all_scores: List[float] = []
    for start in range(0, len(passages), state.reranker_batch):
        batch = passages[start : start + state.reranker_batch]
        pairs = [[claim, p] for p in batch]
        enc = state.reranker_tokenizer(
            pairs,
            max_length=state.reranker_max_len,
            padding=True,
            truncation=True,
            return_tensors="pt",
        ).to(state.device)
        logits = state.reranker_model(**enc).logits.view(-1).float().cpu().numpy()
        all_scores.extend(logits.tolist())
    return all_scores


# ─────────────────────────────────────────────────────────────────────
# Public retrieve()
# ─────────────────────────────────────────────────────────────────────

def retrieve(
    state: RetrieverState,
    claim: str,
    top_k: int = 5,
    k_per_side: int = 10,
    top_n_fused: int = 20,
) -> List[Passage]:
    """
    Full hybrid retrieval for one claim.

    Pipeline
    --------
    BM25s top-k_per_side  ┐
                          ├─ RRF fusion → top_n_fused candidates
    Dense   top-k_per_side ┘
                          ↓
                          Fetch passage texts from Qdrant payload
                          ↓
                          Cross-encoder rerank
                          ↓
                          top_k Passage objects (sorted by rerank_score desc)

    Returns
    -------
    list[Passage] of length up to top_k. Empty list if no candidates survive
    (e.g. Qdrant payload fetch returned nothing — should never happen in a
    healthy deployment, but the caller should handle it).
    """
    # 1. Retrieve both sides
    bm25_hits = _bm25_search(state, claim, k=k_per_side)
    dense_hits = _dense_search(state, claim, k=k_per_side)

    # 2. RRF fusion
    fused = _reciprocal_rank_fusion([bm25_hits, dense_hits])
    cand_pids = [pid for pid, _ in fused[:top_n_fused]]

    # 3. Fetch passage texts from Qdrant payload via integer point IDs
    cand_qids = [state.pid_to_qid[pid] for pid in cand_pids if pid in state.pid_to_qid]
    if not cand_qids:
        return []

    qdrant_pts = state.qdrant_client.retrieve(
        collection_name=state.collection,
        ids=cand_qids,
        with_payload=True,
    )
    pid_to_text = {pt.payload["passage_id"]: pt.payload["text"] for pt in qdrant_pts}

    # Preserve fusion order; skip any pids absent from Qdrant payload fetch
    cand_pairs = [(pid, pid_to_text[pid]) for pid in cand_pids if pid in pid_to_text]
    if not cand_pairs:
        return []

    cand_pids_present = [p[0] for p in cand_pairs]
    texts = [p[1] for p in cand_pairs]

    # 4. Cross-encoder rerank
    scores = _rerank(state, claim, texts)
    ranked = sorted(
        zip(cand_pids_present, texts, scores),
        key=lambda x: x[2],
        reverse=True,
    )[:top_k]

    # 5. Build Passage objects
    out: List[Passage] = []
    for pid, text, score in ranked:
        parts = pid.rsplit("::", 1)
        page_id = parts[0] if len(parts) == 2 else pid
        sent_id = parts[1] if len(parts) == 2 else "?"
        sim = 1.0 / (1.0 + math.exp(-score))
        out.append(Passage(
            passage_id=pid,
            page_id=page_id,
            sentence_id=sent_id,
            text=text,
            title=page_id.replace("_", " "),
            url=f"https://en.wikipedia.org/wiki/{page_id}",
            rerank_score=round(score, 4),
            similarity=round(sim, 4),
        ))
    return out
