from __future__ import annotations

import asyncio
import logging
import math
import time
from typing import AsyncIterator, List


# Custom pipeline exceptions for router mapping
class PipelineError(Exception):
    code: str = "PIPELINE_FAILURE"


class NoClaimsFound(PipelineError):
    code = "NO_CLAIMS_FOUND"


class RetrievalFailure(PipelineError):
    code = "RETRIEVAL_FAILURE"


class ClassificationFailure(PipelineError):
    code = "CLASSIFICATION_FAILURE"


# Constants / policy
TAU = 0.85
MIN_DECISIVE_CONF = 0.6


async def stage_extract(paragraph: str, extractor_state):
    from services.extractor import extract_with_spans

    try:
        claims = extract_with_spans(extractor_state, paragraph)
    except Exception as e:
        raise NoClaimsFound(str(e))

    if not claims:
        raise NoClaimsFound("No claims extracted from paragraph")

    return claims


async def stage_retrieve(claims, retriever_state):
    all_passages: List[List] = []
    claim_times: List[float] = []
    from services.retriever import retrieve

    try:
        for c in claims:
            claim_t0 = time.perf_counter()
            ps = retrieve(retriever_state, c.text, top_k=5)
            all_passages.append(ps)
            claim_times.append(time.perf_counter() - claim_t0)
    except Exception as e:
        raise RetrievalFailure(str(e))

    return all_passages, claim_times


async def stage_classify(claims, all_passages, classifier_state):
    all_classifications: List[List[dict]] = []
    claim_times: List[float] = []
    from services.classifier import classify_batch

    try:
        for c, passages in zip(claims, all_passages):
            claim_t0 = time.perf_counter()
            texts = [p.text for p in passages]
            cls = classify_batch(classifier_state, c.text, texts)
            all_classifications.append(cls)
            claim_times.append(time.perf_counter() - claim_t0)
    except Exception as e:
        raise ClassificationFailure(str(e))

    return all_classifications, claim_times


async def stage_aggregate_and_explain(
    claims,
    all_passages,
    all_classifications,
    explainer_state,
):
    # 4. Aggregate per-claim using label-priority
    results = []
    for claim, passages, classifications in zip(claims, all_passages, all_classifications):
        scored = []
        for p, cl in zip(passages, classifications):
            scored.append({
                "passage": p,
                "predicted_label": cl["label"],
                "predicted_conf": float(cl.get("confidence", 0.0)),
                "similarity": float(getattr(p, "similarity", 0.0)),
                "rerank_score": float(getattr(p, "rerank_score", 0.0)),
            })

        confident = [s for s in scored if s["predicted_conf"] >= MIN_DECISIVE_CONF]
        pool = confident if confident else scored

        def highest_sim_of(label_name: str):
            cand = [s for s in pool if s["predicted_label"] == label_name]
            if not cand:
                return None
            return max(cand, key=lambda x: x["similarity"])

        chosen_entry = highest_sim_of("SUPPORTS") or highest_sim_of("REFUTES") or max(pool, key=lambda x: x["similarity"]) if pool else None

        if chosen_entry is None:
            five_way = "uncertain"
            top_passage = None
            top_conf = 0.0
            top_sim = 0.0
        else:
            top_passage = chosen_entry["passage"]
            top_label = chosen_entry["predicted_label"]
            top_conf = chosen_entry["predicted_conf"]
            top_sim = chosen_entry["similarity"]

            if top_label == "REFUTES":
                five_way = "hallucinated"
            elif top_label == "SUPPORTS":
                five_way = "factual" if top_sim >= TAU else "uncertain"
            else:
                five_way = "knowledge_gap" if top_sim >= TAU else "likely_hallucinated"

        if five_way == "factual":
            api_verdict = "factual"
        elif five_way in ("hallucinated", "likely_hallucinated"):
            api_verdict = "hallucinated"
        else:
            api_verdict = "uncertain"

        if top_passage is None:
            evidence = None
            api_verdict = "uncertain"
        else:
            evidence = {
                "snippet": top_passage.text,
                "article_title": top_passage.title,
                "article_url": top_passage.url,
            }

        results.append(
            {
                "claim": claim,
                "api_verdict": api_verdict,
                "five_way": five_way,
                "confidence": float(top_conf),
                "source_relevance": float(top_sim),
                "evidence": evidence,
            }
        )

    async def _none_coro():
        return None

    explain_tasks = []
    from services.explainer import explain as explainer_explain

    explain_call_count = 0
    for r in results:
        if r["api_verdict"] in ("hallucinated", "uncertain") and r["evidence"] is not None:
            explain_call_count += 1
            explain_tasks.append(
                explainer_explain(explainer_state, r["claim"].text, r["evidence"]["snippet"], r["api_verdict"])
            )
        else:
            explain_tasks.append(_none_coro())

    explanations = await asyncio.gather(*explain_tasks)

    final_claims = []
    for r, explanation in zip(results, explanations):
        c = r["claim"]
        ev = r["evidence"]
        final_claims.append(
            {
                "id": c.id,
                "text": c.text,
                "source_text": c.source_text,
                "start_offset": c.start_offset,
                "end_offset": c.end_offset,
                "verdict": r["api_verdict"],
                "confidence": r["confidence"],
                "source_relevance": r["source_relevance"],
                "explanation": explanation,
                "evidence": ev,
            }
        )

    claims_count = len(final_claims)
    verdicts_count = {"factual": 0, "hallucinated": 0, "uncertain": 0}
    for fc in final_claims:
        verdicts_count[fc["verdict"]] += 1

    hallucination_rate = verdicts_count["hallucinated"] / claims_count if claims_count else 0.0

    return {
        "claims_count": claims_count,
        "hallucination_rate": hallucination_rate,
        "verdicts": verdicts_count,
        "claims": final_claims,
        "_explain_call_count": explain_call_count,
    }


def _log_summary(
    extract_s: float,
    retrieve_s: float,
    retrieve_claim_times: List[float],
    classify_s: float,
    classify_claim_times: List[float],
    explain_s: float,
    explain_call_count: int,
    total_s: float,
    claims_count: int,
):
    retrieve_mean_s = sum(retrieve_claim_times) / len(retrieve_claim_times) if retrieve_claim_times else 0.0
    classify_mean_s = sum(classify_claim_times) / len(classify_claim_times) if classify_claim_times else 0.0
    summary = (
        f"[pipeline] extract={extract_s:.1f}s "
        f"retrieve={retrieve_s:.1f}s ({claims_count} claims, {retrieve_mean_s:.1f}s/claim) "
        f"classify={classify_s:.1f}s ({claims_count} claims, {classify_mean_s:.2f}s/claim) "
        f"explain={explain_s:.1f}s ({explain_call_count} calls) total={total_s:.1f}s"
    )
    logging.info(summary)
    print(summary)


async def verify_paragraph(
    paragraph: str,
    retriever_state,
    classifier_state,
    extractor_state,
    explainer_state,
) -> dict:
    """Run the full pipeline and return a dict matching the API contract.

    Raises PipelineError subclasses for the router to convert to HTTP responses.
    """
    total_t0 = time.perf_counter()

    extract_t0 = time.perf_counter()
    claims = await stage_extract(paragraph, extractor_state)
    extract_s = time.perf_counter() - extract_t0

    retrieve_t0 = time.perf_counter()
    all_passages, retrieve_claim_times = await stage_retrieve(claims, retriever_state)
    retrieve_s = time.perf_counter() - retrieve_t0

    classify_t0 = time.perf_counter()
    all_classifications, classify_claim_times = await stage_classify(claims, all_passages, classifier_state)
    classify_s = time.perf_counter() - classify_t0

    stage_t0 = time.perf_counter()
    result = await stage_aggregate_and_explain(
        claims,
        all_passages,
        all_classifications,
        explainer_state,
    )
    explain_s = time.perf_counter() - stage_t0
    explain_call_count = result.pop("_explain_call_count", 0)

    total_s = time.perf_counter() - total_t0
    _log_summary(
        extract_s,
        retrieve_s,
        retrieve_claim_times,
        classify_s,
        classify_claim_times,
        explain_s,
        explain_call_count,
        total_s,
        len(claims),
    )

    return result


async def verify_paragraph_streaming(
    paragraph,
    retriever_state,
    classifier_state,
    extractor_state,
    explainer_state,
) -> AsyncIterator[dict]:
    try:
        yield {"step": 1, "status": "extracting"}
        await asyncio.sleep(0)
        claims = await stage_extract(paragraph, extractor_state)

        yield {"step": 2, "status": "retrieving"}
        await asyncio.sleep(0)
        all_passages, _ = await stage_retrieve(claims, retriever_state)

        yield {"step": 3, "status": "classifying"}
        await asyncio.sleep(0)
        all_classifications, _ = await stage_classify(claims, all_passages, classifier_state)

        result = await stage_aggregate_and_explain(
            claims, all_passages, all_classifications, explainer_state
        )
        yield {"step": 4, "status": "complete", "data": result}
    except NoClaimsFound as e:
        yield {"step": 4, "status": "error", "error": {"code": e.code, "message": "We couldn't find any checkable claims in this text."}}
    except RetrievalFailure as e:
        yield {"step": 4, "status": "error", "error": {"code": e.code, "message": "Retrieval failed."}}
    except ClassificationFailure as e:
        yield {"step": 4, "status": "error", "error": {"code": e.code, "message": "Classification failed."}}
    except PipelineError as e:
        yield {"step": 4, "status": "error", "error": {"code": e.code, "message": "Pipeline failed."}}
    except Exception as e:
        yield {"step": 4, "status": "error", "error": {"code": "PIPELINE_FAILURE", "message": str(e)}}