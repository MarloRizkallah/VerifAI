# Server
HOST=0.0.0.0
PORT=8000
ALLOWED_ORIGINS=http://localhost:3000

# Pipeline limits
MAX_CHARS=2000

# Retriever (Phase 2)
BM25S_INDEX_PATH=/path/to/rag/indices/bm25s
BM25S_IDS_PATH=/path/to/rag/indices/bm25s/passage_ids_bm25s.pkl
QDRANT_HOST=localhost
QDRANT_PORT=6333
QDRANT_COLLECTION=fever_wiki

# Classifier (Phase 2) — comma-separated list of 3 adapter dirs
NLI_ADAPTER_PATHS=/path/to/deberta_single_evidence_v2/adapter_seed_42,/path/to/deberta_single_evidence_v2/adapter_seed_123,/path/to/deberta_single_evidence_v2/adapter_seed_777

# LLM backends (Phase 3 + 4)
EXTRACTOR_PROVIDER=ollama
EXTRACTOR_MODEL=llama3.1:8b
EXPLAINER_PROVIDER=ollama
EXPLAINER_MODEL=llama3.1:8b
OLLAMA_BASE_URL=http://localhost:11434/v1