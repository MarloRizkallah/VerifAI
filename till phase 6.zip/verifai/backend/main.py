"""
VerifAI FastAPI backend — Phase 1 skeleton with mock data
"""

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from config import (
    ALLOWED_ORIGINS,
    BM25S_INDEX_PATH,
    BM25S_IDS_PATH,
    NLI_ADAPTER_PATHS,
    QDRANT_COLLECTION,
    QDRANT_HOST,
    QDRANT_PORT,
    EXTRACTOR_PROVIDER,
    EXTRACTOR_MODEL,
)
from routers import verify
from services.classifier import load_classifier
from services.retriever import load_retriever
from services.extractor import load_extractor
from services.explainer import load_explainer


@asynccontextmanager
async def lifespan(app: FastAPI):
    print("[lifespan] Loading retriever ...")
    app.state.retriever = load_retriever(
        bm25_index_path=BM25S_INDEX_PATH,
        bm25_ids_path=BM25S_IDS_PATH,
        qdrant_host=QDRANT_HOST,
        qdrant_port=QDRANT_PORT,
        collection=QDRANT_COLLECTION,
    )
    print("[lifespan] Loading classifier ...")
    app.state.classifier = load_classifier(adapter_paths=NLI_ADAPTER_PATHS)
    print("[lifespan] Loading extractor ...")
    app.state.extractor = load_extractor(
        llm_provider=EXTRACTOR_PROVIDER,
        llm_model=EXTRACTOR_MODEL,
    )
    print("[lifespan] Loading explainer ...")
    app.state.explainer = load_explainer()
    print(f"[lifespan] explainer ready ({app.state.explainer.model})")
    # Warmup — one dummy pipeline run so the first real request is fast
    print("[lifespan] warming up pipeline...")
    import time
    try:
        from services.pipeline import verify_paragraph

        t0 = time.perf_counter()
        try:
            await verify_paragraph(
                "Albert Einstein was born in 1879.",
                app.state.retriever,
                app.state.classifier,
                app.state.extractor,
                app.state.explainer,
            )
            print(f"[lifespan] warmup complete in {time.perf_counter() - t0:.1f}s")
        except Exception as e:
            print(f"[lifespan] warmup failed (non-fatal): {e}")
    except Exception as e:
        print(f"[lifespan] warmup import failed (non-fatal): {e}")
    print("[lifespan] Startup complete.")
    yield
    print("[lifespan] Shutdown.")


# Create FastAPI app with lifespan
app = FastAPI(
    title="VerifAI Backend",
    description="Hallucination detection pipeline with RAG + NLI",
    version="0.1.0",
    lifespan=lifespan,
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["POST", "OPTIONS"],
    allow_headers=["Content-Type"],
)

# Include routers
app.include_router(verify.router)


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "ok"}
