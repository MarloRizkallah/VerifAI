"""
Pydantic v2 models matching the locked API contract
"""

from typing import List, Optional, Literal
from pydantic import BaseModel, Field


class VerifyRequest(BaseModel):
    paragraph: str


class Evidence(BaseModel):
    snippet: str
    article_title: str
    article_url: str


class Claim(BaseModel):
    id: int
    text: str  # atomic claim, post LLM reformulation
    source_text: str  # parent sentence verbatim from original paragraph
    start_offset: int  # char offset of source_text in original paragraph
    end_offset: int
    verdict: Literal["factual", "hallucinated", "uncertain"]
    confidence: float  # 0.0 - 1.0
    source_relevance: float  # 0.0 - 1.0
    explanation: Optional[str] = None  # null for factual; may be null for others if LLM failed
    evidence: Optional[Evidence] = None  # null only when verdict == "uncertain"


class Verdicts(BaseModel):
    factual: int
    hallucinated: int
    uncertain: int


class VerifyResponse(BaseModel):
    claims_count: int
    hallucination_rate: float  # 0.0 - 1.0
    verdicts: Verdicts
    claims: List[Claim]


class ErrorResponse(BaseModel):
    error: bool = True
    code: str  # INVALID_INPUT | NO_CLAIMS_FOUND | RETRIEVAL_FAILURE | CLASSIFICATION_FAILURE | PIPELINE_FAILURE
    message: str
