# VerifAI Webapp Build Plan

A phased plan for building the VerifAI frontend + backend with Claude Code, given:
- An existing RAG pipeline (Qdrant + BM25s + RRF + gte-reranker) in `RAG_v1_Harrier.ipynb`
- A trained DeBERTa-v3-large + LoRA ensemble (v2 production, Test F1=0.9547)
- The locked API contract and design system in `VERIFAI_HANDOFF.md`
- Five HTML screen references from the Stitch zip

---

## What's already done vs. what's new

| Component | State | Source |
|---|---|---|
| Dense retrieval (Qdrant + Harrier-270m) | Done | `RAG_v1_Harrier.ipynb` Step 4 |
| Sparse retrieval (BM25s — assuming Day 4 Track A is finished by webapp build) | Done | `RAG_v1_Harrier.ipynb` Step 2D/2E + 5B |
| RRF fusion + gte-reranker | Done | `RAG_v1_Harrier.ipynb` Step 5 |
| DeBERTa NLI ensemble (3 seeds) | Done | `deberta_single_evidence_v2/adapter_seed_*` |
| 5-case verdict logic | Done | `RAG_v1_Harrier.ipynb` Step 6 |
| Claim extractor (heuristic + LLM hybrid, atomic decomposition) | Done | `claim_extractor.py` |
| **Span attribution wrapper** (atomic claim → paragraph offsets) | **New** | — |
| **5-case → 3-case verdict mapping** | **New** | — |
| **LLM explainer service** | **New** | — |
| **FastAPI app + lifespan + SSE** | **New** | — |
| **Next.js frontend (5 screens)** | **New** | — |

The plan extracts the existing components into Python modules, layers the new pieces on top, then builds the frontend last.

---

## Phase 0 — Decisions & prep (do these BEFORE opening Claude Code)

Three things to nail down so Claude Code isn't blocked mid-build.

### Decision 1: LLM backend for the extractor + explainer

The existing `claim_extractor.py` uses the hybrid `ClaimExtractor` (heuristic prefilter + LLM atomic decomposition) and supports three backends: `ollama`, `openai`, `anthropic`. The explainer also needs an LLM. Pick one coherent setup:

| Setup | Pros | Cons |
|---|---|---|
| **Both use Ollama llama3.1:8b** | Fully local, no API key, free, deterministic on the lab machine | ~1–3s per extraction + ~1–3s per explanation; tight VRAM alongside DeBERTa + reranker + Harrier; explanation quality lower than frontier models |
| **Extractor → Anthropic Haiku, Explainer → Ollama** | Higher extraction quality (Haiku is fast + cheap); explanations stay local | Adds an API key dep; mild cost |
| **Both → Anthropic Haiku** | Most consistent quality, fastest end-to-end | API key + online dep; not a "pure local" demo story |

**Recommendation:** for a GP demo where you control the lab machine, **both-Ollama** is defensible and gives you a clean "fully local AI pipeline" story for the write-up. For the smoothest demo, **both-Anthropic Haiku** is the easiest path — Haiku is fast and cheap, and the model name `claude-haiku-4-5-20251001` is already in `claim_extractor.py` as the default.

Either way, lock this in via `.env`:
```
EXTRACTOR_PROVIDER=ollama   # or anthropic
EXTRACTOR_MODEL=llama3.1:8b
EXPLAINER_PROVIDER=ollama
EXPLAINER_MODEL=llama3.1:8b
ANTHROPIC_API_KEY=...       # only if using anthropic
```

### Decision 1b: How to attribute claims back to paragraph spans

The existing extractor returns `list[str]` of reformulated atomic claims (pronouns resolved, compounds split). This is correct for downstream NLI quality, but those strings don't substring-match the original paragraph anymore. The frontend highlight feature needs char offsets.

Three options, in order of effort:

| Approach | What gets highlighted | Effort |
|---|---|---|
| **Sentence-level attribution** | The full sentence the atomic claim was derived from | Small — reuse spaCy sent split, map each claim to its parent sentence by word overlap |
| **Phrase-level via word overlap** | The substring in the paragraph with maximum word overlap with the claim | Medium — heuristic, occasionally produces odd spans |
| **Phrase-level via LLM attribution** | The exact source phrase the LLM identifies for each claim | Largest — extend the LLM system prompt to return `[{"claim":..., "source_phrase":...}]` and validate phrases exist in the paragraph |

**Recommendation:** **Sentence-level for v1.** It's robust, doesn't touch the existing extractor, and the UX still works — clicking a highlighted sentence scrolls to whichever claim card came from it. The mockup shows phrase-level highlights, but achieving them reliably is a polish item.

**Color handling when multiple atomic claims share a sentence:** worst-verdict-wins (hallucinated > uncertain > factual). If a sentence contains one hallucinated and one factual claim, highlight it red. The cards on the right still render each atomic claim separately with its own verdict.

```python
# services/extractor.py contract — thin wrapper over claim_extractor.py
def extract(paragraph: str) -> list[Claim]:
    # where Claim = {
    #   id: int,
    #   text: str,              # atomic claim (from existing extractor)
    #   source_text: str,       # parent sentence in original paragraph
    #   start_offset: int,      # char offset of parent sentence in paragraph
    #   end_offset: int,
    # }
```

### Decision 2: 5-case → 3-case verdict mapping

Your pipeline emits 5 verdicts; the API contract has 3. Lock in this mapping:

| Pipeline verdict | API verdict | Reasoning |
|---|---|---|
| `factual` | `factual` | Direct |
| `hallucinated` | `hallucinated` | Direct |
| `likely_hallucinated` | `hallucinated` | NEI + sim<TAU — model wasn't sure but no support found |
| `uncertain` | `uncertain` | SUPPORTS but low similarity to evidence |
| `knowledge_gap` | `uncertain` | NEI + sim≥TAU — gold evidence exists but isn't informative |

This is the natural mapping but worth confirming with your advisor since it affects how the hallucination rate is calculated.

### Decision 3: Ollama setup (if using Ollama for either component)

If Decision 1 selects Ollama for the extractor and/or explainer, the handoff assumes `llama3.1:8b` is running locally on `http://localhost:11434`. Before opening Claude Code:

```bash
# Install Ollama (Linux)
curl -fsSL https://ollama.com/install.sh | sh

# Pull the model (~4.7 GB)
ollama pull llama3.1:8b

# Verify it works
ollama run llama3.1:8b "Say hello in one sentence"
```

Do this on the lab machine, not the laptop. The 8B model needs ~6 GB VRAM and the RTX 5000s are already busy with DeBERTa + reranker + Harrier — confirm there's headroom, or plan to load Ollama on the second GPU (`CUDA_VISIBLE_DEVICES=1 ollama serve`).

If Decision 1 selects Anthropic for everything, skip this step — just set `ANTHROPIC_API_KEY` in `.env`.

### Pre-flight checklist

Before Phase 1:

- [ ] Day 4 Track A (`bm25s` swap) merged into `RAG_v1_Harrier.ipynb` — eliminates the 80–110s/claim bottleneck
- [ ] Qdrant collection name and BM25s index path noted down (Claude Code will reference these in `.env`)
- [ ] `deberta_single_evidence_v2/adapter_seed_{42,123,777}/` paths confirmed accessible
- [ ] `claim_extractor.py` placed somewhere Claude Code can import it from (suggest `backend/services/claim_extractor.py`)
- [ ] `python -m spacy download en_core_web_sm` run in the backend venv
- [ ] LLM backend decision made (Decision 1)
- [ ] Ollama running + `llama3.1:8b` pulled (if applicable per Decision 1) OR `ANTHROPIC_API_KEY` ready
- [ ] Span attribution approach picked (Decision 1b — sentence-level recommended)
- [ ] Verdict mapping confirmed (Decision 2)
- [ ] Empty `verifai/` directory created with `frontend/` and `backend/` subfolders

**Built as (✓ verified):**
- Decision 1 (LLM backend): `EXTRACTOR_PROVIDER=ollama`, `EXTRACTOR_MODEL=llama3.1:8b`; `EXPLAINER_PROVIDER=ollama`, `EXPLAINER_MODEL=llama3.1:8b` — both Ollama on the lab machine (Anthropic out of scope until Phase 14)
- Decision 1b (span attribution): sentence-level attribution via Jaccard word overlap with longest-sentence fallback when similarity < 0.05
- Decision 2 (verdict mapping): 5→3 mapping locked as documented above (`factual→factual`, `hallucinated|likely_hallucinated→hallucinated`, `uncertain|knowledge_gap→uncertain`)
- Ollama setup: installed on lab; data dir relocated to `/media/ai-ws2/New Volume/ollama_data` (symlink + ACL fix); `OLLAMA_KEEP_ALIVE=30m` set via systemd override
- Verified: Decisions and Ollama setup validated on the lab machine; span-attribution approach confirmed via extractor tests

---

## Phase-by-phase build

Each phase is one or two focused Claude Code sessions. Verify each before moving on. Don't let Claude Code chain phases together — that's how big refactors quietly overwrite working code.

**Built as (✓ verified):**
- `verifai/backend/main.py` — FastAPI app with lifespan, CORS, and startup stubs that previously returned the mock
- `verifai/backend/config.py` — `.env`-backed config loader used by services
- `verifai/backend/models/schemas.py` — Pydantic request/response shapes matching the contract
- `verifai/backend/routers/verify.py` — `/verify` POST initially implemented as a hardcoded mock (replaced later by the real pipeline in Phase 5)
- `verifai/backend/.env` and `.env.example` + `verifai/backend/requirements.txt`
- Deviation: the initial mock in `routers/verify.py` was intentionally replaced by the real pipeline during Phase 5
- Verified: curl against the running dev server returned the Great Wall / Einstein mock as expected

### Phase 1 — Backend skeleton with mock pipeline

**Goal:** A runnable FastAPI app that returns a hardcoded valid response, so the frontend has something to develop against from day one.

**Build:**
- `backend/main.py` — FastAPI app, CORS, lifespan stub
- `backend/config.py` — loads `.env` via `python-dotenv`
- `backend/models/schemas.py` — Pydantic shapes matching the locked API contract exactly
- `backend/routers/verify.py` — `/verify` POST endpoint that returns a hardcoded response matching the contract (use the Einstein/Great Wall example from the handoff as the mock)
- `backend/.env` and `.env.example` — gitignored, with placeholders
- `backend/requirements.txt` — fastapi, uvicorn, pydantic, python-dotenv, sse-starlette

**No SSE yet.** Return plain JSON. SSE comes in Phase 6 once the underlying pipeline is real.

**Verify:**
```bash
cd backend && uvicorn main:app --reload --port 8000
curl -X POST http://localhost:8000/verify \
  -H "Content-Type: application/json" \
  -d '{"paragraph": "test"}'
# → should return the full hardcoded response with claims, verdicts, evidence, etc.
```

**Claude Code prompt sketch:**
> Build the FastAPI backend skeleton in `backend/` following the structure in `VERIFAI_HANDOFF.md` (Folder Structure section). The `/verify` endpoint should accept `{paragraph: str}` and return a hardcoded response matching the API contract exactly — use the Great Wall example as the mock data. Include lifespan stub (no actual model loading yet), CORS for `localhost:3000`, and load all config from `.env`. Add a 422 response for empty or >2000 char input.

---

**Built as (✓ verified):**
- `verifai/backend/services/retriever.py` — `load_retriever()`, `retrieve(state, claim, top_k=5) -> list[Passage]`; hybrid pipeline: BM25s + Harrier dense embeds + RRF fusion + `gte` cross-encoder reranker
- `verifai/backend/services/classifier.py` — `load_classifier()`, `classify_batch(state, claim, passages) -> list[dict]`; 3 LoRA adapters with logit-averaging
- `Passage.similarity` is defined as `sigmoid(rerank_score)` and used downstream for TAU-based decisions
- Deviation: none functional — code is a port of the notebook steps into services modules
- Verified: lab smoke tests — Einstein → SUPPORTS, Eiffel→REFUTES; retrieval <2s warm, classification ~<0.5s per claim

### Phase 2 — Extract retriever & classifier from notebooks

**Goal:** Move existing pipeline code from `RAG_v1_Harrier.ipynb` and the DeBERTa fine-tuning notebook into proper Python modules. No new logic — just refactoring.

**Build:**
- `backend/services/retriever.py` — exposes:
  - `load_retriever()` → loads Qdrant client, Harrier embedder, BM25s index, gte-reranker
  - `retrieve(claim: str, top_k: int = 5) -> list[Passage]` → returns reranked top-k passages with text, title, url, rerank_score
- `backend/services/classifier.py` — exposes:
  - `load_classifier()` → loads 3 DeBERTa LoRA adapters
  - `classify(claim: str, passage: str) -> dict` → returns `{label, confidence, label_logits}` for one (claim, passage) pair

**Critical:** keep the function signatures clean. The retriever returns passages; the classifier classifies pairs. The 5-case verdict logic does NOT live in either — it lives in the pipeline composition function (Phase 5).

**Wire into FastAPI lifespan:**
```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.retriever = load_retriever()
    app.state.classifier = load_classifier()
    yield
```

**Verify:** Write a tiny test script that calls `retrieve("The Great Wall is visible from space")` and prints the top-5 passages. Then calls `classify(claim, passages[0].text)` and prints the result. Should match what Step 5/6 of your RAG notebook produce.

**Claude Code prompt sketch:**
> I have working retrieval code in `RAG_v1_Harrier.ipynb` (Step 4 = Qdrant load, Step 5 = hybrid search with RRF + reranker) and DeBERTa inference code in `DeBERTa_Final_NoMultiv2.ipynb` (Step 6 = `nli_predict_batch`). Extract these into `backend/services/retriever.py` and `backend/services/classifier.py` as standalone modules with `load_*` and the inference functions. Do not change the underlying logic — just port it. Then wire them into the FastAPI lifespan so models load once at startup.

**Important:** point Claude Code at the specific cells. Don't say "port the notebook" — say "port Step 5 and Step 6 specifically".

---

**Built as (✓ verified):**
- `verifai/backend/services/claim_extractor.py` — verbatim hybrid heuristic+LLM extractor (left unmodified)
- `verifai/backend/services/extractor.py` — `load_extractor()` and `extract_with_spans(state, paragraph) -> list[Claim]` returning `id, text, source_text, start_offset, end_offset` via spaCy sentence splitting + Jaccard attribution
- Deviation: none — wrapper preserves `ClaimExtractor` behavior and adds sentence-level span attribution
- Critical pip lesson: avoid `pip install --user spacy` without checking for `Uninstalling numpy`/`Uninstalling torch`; pinned fix: `pip install --user "numpy<2"` when needed
- Verified: `paragraph[start:end] == source_text` assertion holds across test paragraphs

### Phase 3 — Integrate the existing claim extractor + span attribution wrapper

**Goal:** `services/extractor.py` that wraps the existing `ClaimExtractor` and adds char-offset attribution so the frontend can highlight claims in the original paragraph.

**Build:**
- Drop `claim_extractor.py` into `backend/services/` as-is — do NOT rewrite it
- Create a thin wrapper module `backend/services/extractor.py`:
  - `load_extractor()` instantiates `ClaimExtractor(use_llm=..., llm_provider=..., llm_model=...)` per `.env`
  - `extract_with_spans(paragraph: str) -> list[Claim]`:
    1. Split paragraph into sentences using spaCy, recording `(text, start, end)` char offsets for each
    2. Call `ClaimExtractor.extract(paragraph)` to get atomic claim strings
    3. For each atomic claim, attribute it to the parent sentence with the highest word overlap (Jaccard on lowercased word sets)
    4. Return `[{id, text, source_text, start_offset, end_offset}, ...]` — multiple claims may share the same `source_text` and offsets, and that's fine
- Wire `load_extractor()` into the FastAPI lifespan so the spaCy model loads once at startup

**Critical assertion to add as a test:**
```python
for claim in claims:
    assert paragraph[claim.start_offset:claim.end_offset] == claim.source_text
```
If this fails, the frontend highlight feature breaks silently. The atomic claim `text` does NOT need to match — it's intentionally reformulated. Only `source_text` needs to recover from offsets.

**Edge case to handle in the wrapper:** if an atomic claim has near-zero word overlap with every sentence (rare but possible with aggressive LLM rewrites), fall back to attributing it to the longest sentence in the paragraph and log a warning.

**Verify:**
```python
paragraph = "Einstein was born in Germany in 1879. He won the Nobel Prize in 1921."
claims = extractor.extract_with_spans(paragraph)
# Expect ≥2 atomic claims
# Expect claims[1].text ≈ "Einstein won the Nobel Prize in 1921." (He → Einstein resolved)
# Expect claims[1].source_text == "He won the Nobel Prize in 1921."
# Expect paragraph[claims[1].start_offset:claims[1].end_offset] == claims[1].source_text
```

**Claude Code prompt sketch:**
> The file `backend/services/claim_extractor.py` already exists — it has a `ClaimExtractor` class that returns `list[str]` of atomic, self-contained factual claims. Build a thin wrapper `backend/services/extractor.py` that calls it AND attributes each atomic claim back to its parent sentence in the original paragraph via spaCy sentence splitting + word-overlap matching. Return claims with char offsets so the frontend can highlight them. Do NOT modify `claim_extractor.py`. Read the LLM backend from `.env` and pass it through to `ClaimExtractor`.

---

**Built as (✓ verified):**
- `verifai/backend/services/explainer.py` — `load_explainer()`, `async def explain(state, claim, evidence_snippet, verdict) -> str | None`; uses Ollama via the OpenAI-compatible client wrapper
- Deviation: initial scaffold (from Claude Code) used a legacy `ChatCompletion` pattern; this was corrected to use `openai.OpenAI(...)` and a small `OllamaClientWrapper` was removed
- Guards: explainer is gated to run only for `hallucinated`/`uncertain`; empty-string or timeout returns `None`; output length bounded 20–800 chars
- Verified: 4 real cases produced grounded explanations; factual claims returned `null` immediately; mean warm latency ~1.2s

### Phase 4 — Explainer

**Goal:** `services/explainer.py` that generates 2–3 sentence explanations for hallucinated/uncertain claims.

**Build:**
- `async def explain(claim: str, evidence_snippet: str, verdict: str) -> str | None`
- Use the LLM backend chosen in Decision 1 — same backend as the extractor for consistency. Reuse the client-building pattern from `claim_extractor.py` (it already supports ollama/openai/anthropic, so you can lift it directly)
- Wraps every call in try/except — if the LLM is down, times out, or returns garbage, return `None`
- Prompt template: "The claim is [X]. The Wikipedia evidence is [Y]. The verification verdict is [Z]. In 2–3 plain sentences, explain why this verdict was reached. Base your explanation ONLY on the evidence snippet provided. Do not introduce outside information."
- Only called for `hallucinated` and `uncertain` API verdicts — never for `factual`

**Verify:**
- Stop the LLM backend, call `explain(...)` → returns `None`, no exception bubbles up
- Start the LLM backend, call `explain(...)` → returns a string of reasonable length (50–200 words)

**Sanity check before moving on:** run 10 hand-crafted hallucinated claims through it and eyeball the explanations. Confirm the LLM isn't introducing outside knowledge that contradicts the evidence — if it does, tighten the prompt.

---

**Built as (✓ verified):**
- `verifai/backend/services/pipeline.py` — `verify_paragraph(...)` async function plus custom exceptions `PipelineError`, `NoClaimsFound`, `RetrievalFailure`, `ClassificationFailure`
- Verdict aggregation: label-priority (SUPPORTS > REFUTES > NEI) with `MIN_DECISIVE_CONF=0.6` and `TAU=0.85` compared against `Passage.similarity` (sigmoid'd rerank score); 5→3 mapping applied before returning API verdicts
- Explanations are run in parallel via `asyncio.gather`; factual verdicts short-circuit to `explanation=None`
- `routers/verify.py` updated to call the pipeline and map exceptions to HTTP responses per the contract
- Lifespan warmup: `main.py` executes one dummy `verify_paragraph()` after services load to eliminate cold-starts (~20s startup cost)
- Per-stage timing is emitted in logs: `[pipeline] extract=Xs retrieve=Ys classify=Zs explain=Ws total=Ts`
- Verified: end-to-end on lab via uvicorn + curl; Eiffel/Berlin → hallucinated with strong confidence; full flow ~5s warm

### Phase 5 — Pipeline composition + verdict mapping

**Goal:** A single plain async function that takes a paragraph and returns the full API response. No SSE yet — that's the next phase.

**Build:**
- `backend/services/pipeline.py` exposing `async def verify_paragraph(paragraph: str) -> dict`
- Internal flow:
  1. `claims = extractor.extract_with_spans(paragraph)` — each claim has `text` (atomic, reformulated) and `source_text`+offsets (parent sentence). Fail with `NO_CLAIMS_FOUND` if empty
  2. For each claim, run `passages = retriever.retrieve(claim.text)` — note: use the atomic claim text for retrieval, NOT the parent sentence (atomic claims retrieve better because they're self-contained)
  3. For each (claim, top passage), run `classifier.classify(...)`
  4. Apply 5-case verdict logic, then map 5→3 per Phase 0 Decision 2
  5. For hallucinated/uncertain claims, call `explainer.explain(...)`
  6. Compute aggregate stats (claims_count, hallucination_rate, verdict counts)
  7. Build and return the response dict matching the API contract exactly — include `source_text` and offsets per claim for the frontend to use for highlighting
- Update `routers/verify.py` to call this function instead of returning the hardcoded mock

**A schema note:** the API contract in the handoff doesn't currently include `source_text` / offsets on each claim — but the frontend highlight feature can't work without them. Add them to the schema as additional fields per claim. They're additive and don't break anything.

**Why keep it plain (not SSE) here:** the handoff explicitly says "Keep pipeline logic completely separate from the SSE transport layer ... This makes reverting to synchronous easy if needed."

**Verify:** real end-to-end via curl. Test paragraph → real claims → real retrieval → real classification → real explanations → response shape matches contract. Confirm each claim's `paragraph[start:end] == source_text`.

This is the milestone where the backend becomes actually useful. Worth a thorough check before continuing.

---

**Built as (✓ verified):**
- `verifai/backend/services/pipeline.py` — refactored into stage helpers `stage_extract`, `stage_retrieve`, `stage_classify`, `stage_aggregate_and_explain` plus async generator `verify_paragraph_streaming(...)` while preserving `verify_paragraph()` wrapper for plain use
- `verifai/backend/routers/verify.py` — now returns `EventSourceResponse` wrapping the streaming generator; input validation (INVALID_INPUT) still performed before opening the stream
- Buffering bug fixed: inserted `await asyncio.sleep(0)` after each yield so events flush immediately instead of arriving clumped at the end
- `requirements.txt` updated to include `httpx` to support `test_phase6.py` clients
- Verified: SSE smoke on lab — 4 events arrive at distinct timestamps consistent with stage completion times (~0.7s, ~1.9s, ~1.0s deltas)

### Phase 6 — SSE transport layer

**Goal:** Wrap `verify_paragraph()` in a streaming SSE endpoint that emits step events.

**Build:**
- Refactor `routers/verify.py` to return `EventSourceResponse` (from `sse-starlette`)
- Emit `{step: 1, status: "extracting"}` before extraction, `{step: 2, ...}` before retrieval, `{step: 3, ...}` before classification, `{step: 4, status: "complete", data: <full response>}` at the end
- Internally still call the same `verify_paragraph` function, just instrumented with progress callbacks — OR split into 4 awaited stages so SSE can emit between them

**Verify:**
```bash
curl -N -X POST http://localhost:8000/verify \
  -H "Content-Type: application/json" \
  -d '{"paragraph": "..."}'
# → should see 4 streaming events arrive sequentially
```

**Revert safety:** if SSE causes problems, the `verify_paragraph` function is intact — swap back to plain JSON in 10 lines.

---

### Phase 7 — Frontend setup

**Goal:** Next.js app skeleton with design tokens, fonts, and routing.

**Build:**
- `npx create-next-app frontend` — App Router, Tailwind, JS (not TS unless you want it)
- `frontend/styles/globals.css` — Tailwind base + the verdict highlight classes from the handoff
- `frontend/tailwind.config.js` — colors and font families from DESIGN.md, BUT override `background` to `#F5F3EF` (stone, per the handoff) instead of the lavender `#fbf8ff` in the design tokens
- `frontend/app/layout.js` — global Source Serif 4 + Inter from Google Fonts, stone background
- `frontend/context/VerifAIContext.jsx` — the 5-field state from the handoff (`paragraph`, `currentStep`, `response`, `error`, `status`)
- `frontend/.env.local` — `NEXT_PUBLIC_API_URL=http://localhost:8000`
- Empty stub pages for `/` and `/verify`

**Verify:** `npm run dev`, visit `localhost:3000` — page renders with stone background, Source Serif 4 visible if you put a placeholder `<h1>`.

**Stone vs lavender clarification:** the HTML references all use `surface: #fbf8ff` (a faint lavender). The handoff overrides this to `#F5F3EF` (stone) as "non-negotiable." Override at the Tailwind config level so all components inherit it.

---

### Phase 8 — Landing page

**Goal:** `/` route matching `verifai_landing_with_three_info_blocks/screen.png`.

**Build:** `components/landing/Hero.jsx`, `components/landing/InfoBlocks.jsx`, header with logo (clicking resets state and navigates to `/`), footer.

**Reference:** port from `verifai_landing_with_three_info_blocks/code.html` — it has the exact Tailwind classes already. Strip the Material Symbols Outlined dependency in favor of lucide-react or inline SVG (cleaner React idiom).

**Info block content:** the three blocks in the design are just labels with no link targets specified. Either link them to placeholder `#` anchors or to short markdown pages (`/about/hallucinations` etc) — flag this decision in the prompt to Claude Code.

---

### Phase 9 — Input screen

**Goal:** `/verify` in `idle` status — textarea + char counter + submit button.

**Build:**
- `components/verify/InputSection.jsx`
- Client-side validation: empty submit and >2000 chars
- On submit: call `useVerify()` hook (which will be mocked for now — returns hardcoded response after a setTimeout)
- Status transition: `idle` → `loading`

**Mock the hook first:** `hooks/useVerify.js` with the SSE logic stubbed to just await 3 seconds, step the counter 1→2→3→4, then resolve with hardcoded data. Real SSE wiring comes in Phase 13.

**Reference:** `verifai_interactive_analysis_flow/code.html`.

---

### Phase 10 — Loading screen

**Goal:** `/verify` in `loading` status — the 4-step horizontal indicator.

**Build:** `components/verify/LoadingIndicator.jsx`. Driven by `currentStep` from context. Three visual states per step: pending (muted), active (indigo container + spinner), completed (green check). Steps connected by a horizontal line.

**Reference:** `verifai_fixed_sequential_loading_sequence/code.html` — the design has icons + labels already.

**Verify:** with the mock hook from Phase 9, hit submit → the 4-step indicator advances through the states correctly.

---

### Phase 11 — Results screen (the big one)

**Goal:** `/verify` in `complete` status — Verification Map + Detailed Breakdown.

This is the most complex phase. Break it into sub-tasks so Claude Code doesn't try to build it all in one shot:

**11a — Layout:** two-column grid (7/12 left, 5/12 right), Verification Map card on left, Detailed Breakdown header on right.

**11b — Highlighted paragraph:** `components/verify/HighlightedParagraph.jsx`. Takes paragraph string + claims array with offsets. Group claims by their `(start_offset, end_offset)` — multiple atomic claims may share a parent sentence. For each unique span, wrap it in a `<span>` with the appropriate verdict highlight class using **worst-verdict-wins coloring** (hallucinated > uncertain > factual). Clicking a span scrolls to the first claim card from that group. Render the paragraph segments between/outside spans as plain text.

**11c — Quick Statistics:** hallucination rate (plain number in error red, NOT a ring chart) + 4 ring charts (Total, Factual, Hallucinated, Uncertain).

**11d — Ring chart component:** `components/ui/RingChart.jsx`, reusable SVG. Empty rings render correctly when value is 0 (edge case from the handoff).

**11e — Claim cards:** `components/ui/ClaimCard.jsx` + container with scroll and bottom fade gradient. Card has: 4px colored left border, claim text + verdict badge top, confidence bar, source relevance bar, evidence block (all claims), explanation block (hallucinated/uncertain only, hidden if null).

**11f — Scroll-to-card:** click a highlight → use a ref map to scroll the matching card into view with a brief flash highlight.

**Reference:** `verifai_comprehensive_evidence_analysis/code.html` — has the full layout. Note the design uses ring chart numbers like "08", "03", "01" (zero-padded) — small detail worth preserving.

---

### Phase 12 — Error screen

**Goal:** `/verify` in `error` status.

**Build:** centered card, exclamation icon, headline, plain-language message (mapped from error code per the handoff table), "Try again" button, "Back to home" link.

**Apply the handoff's two tweaks:**
- Original HTML reference shows "Veritas Editorial" branding + Archive/Methodology nav + profile icon — **strip all of these** in favor of the VerifAI shield logo only
- Original shows "ERROR CODE: ERR_ANALYSIS_TIMEOUT_04" at the bottom of the card — **hide this** per handoff

Both "Try again" and "Back to home" reset the full context state.

**Reference:** `verifai_error_state/code.html` — port the card layout, strip the nav and error code line.

---

### Phase 13 — Real SSE wiring

**Goal:** Replace the mock `useVerify` hook with the real streaming fetch from the handoff.

**Build:** the streaming fetch + line parser exactly as the handoff specifies. Same hook interface so nothing downstream changes.

**Verify:**
- Start backend (Phase 6) on :8000
- Start frontend on :3000
- Submit a paragraph → see all 4 loading steps update in real time → see results render with real data

If this works end-to-end, you have a working webapp.

---

### Phase 14 — Edge cases & polish

The handoff enumerates these — run through them deliberately:

- [ ] Empty paragraph submit → inline error, no API call
- [ ] >2000 chars → button disabled, inline error
- [ ] Zero claims found → error screen with `NO_CLAIMS_FOUND` message
- [ ] Single claim — results render, ring charts don't break
- [ ] All claims same verdict — empty rings render as empty, not broken
- [ ] Long claim text wraps inside card
- [ ] No evidence for a claim (verdict=uncertain, evidence=null) — no empty box
- [ ] Explanation is null — no empty box
- [ ] Logo click from any screen resets state and returns to `/`
- [ ] Backend down → "Couldn't reach the server" message
- [ ] Ollama down → factual + hallucinated/uncertain claims still render, just without explanations

---

## How to prompt Claude Code effectively

Lessons from your prior style preferences and the shape of this project:

1. **One phase per session.** Don't ask Claude Code to build Phases 5–8 in one go. It will produce a sprawling diff that's hard to review and silently overwrites things.

2. **Point at specific files and cells.** "Port Step 5 of `RAG_v1_Harrier.ipynb`" beats "port the retrieval code." Claude Code will find the right cells from the headings.

3. **Always include the handoff doc + plan in context.** Drop both `VERIFAI_HANDOFF.md` and this plan in the conversation. They're the source of truth for the contract.

4. **Verify each phase before continuing.** Run the verification step from the plan. If it doesn't pass, stay in that phase.

5. **For the backend, build the mock first.** Phase 1 lets the frontend start developing immediately against a working endpoint. Don't skip it.

6. **For the frontend, port HTML references one screen at a time.** Each Stitch HTML file is a high-quality reference — give Claude Code the file path and say "port this to React, using the design tokens in `tailwind.config.js`." Faster and more accurate than freeform.

7. **Resist scope creep.** If Claude Code suggests "while we're here, let's also add X" — say no. Note it down, finish the phase, decide later.

---

## Risks & gotchas

- **Claim offsets:** the existing extractor returns reformulated atomic claims that no longer substring-match the paragraph. The span attribution wrapper bridges this — but if word-overlap matching falls back to attributing a claim to the wrong sentence, the highlight points to the wrong place and clicking jumps to the wrong card. Verify with the assertion in Phase 3 and eyeball-test with a paragraph that has 4+ sentences.

- **Phrase-level highlights (polish):** the mockup shows highlights at phrase granularity ("Emperor Qin Shi Huang", "standard industrial concrete") rather than full-sentence granularity. The v1 plan does sentence-level. If you want phrase-level later, the cleanest upgrade is to modify the LLM extraction prompt to also return `source_phrase` per claim, then substring-search the paragraph for each phrase. Treat this as a Phase 14 polish item, not a v1 blocker.

- **Background color drift:** the Stitch HTML uses `#fbf8ff`, the handoff mandates `#F5F3EF`. Override at the Tailwind level before porting screens.

- **VRAM on lab machine:** DeBERTa ensemble (×3 adapters loaded at once) + reranker + Harrier embedder + potentially Ollama 8B (for extractor AND/OR explainer) is ambitious on one 16.7GB GPU. Monitor `nvidia-smi` after Phase 2 finishes. If tight: load DeBERTa adapters sequentially inside `nli_predict_batch` (as you already do in Step 6A), and/or pin Ollama to the second GPU with `CUDA_VISIBLE_DEVICES=1 ollama serve`. Switching to Anthropic backend for the extractor and/or explainer (Decision 1) removes the Ollama VRAM cost entirely.

- **Latency budget:** the handoff promises "~3–8 seconds per analysis." With Ollama LLM extraction (~1–3s) + retrieval (~1s with bm25s) + DeBERTa ensemble (~0.1s/claim × N) + Ollama explanations (~1–3s × M hallucinated/uncertain claims), a paragraph with 6 claims and 3 hallucinations easily hits 10–15s. If that's unacceptable, options: (a) Anthropic Haiku is roughly 5× faster than Ollama 8B; (b) parallelize explanation calls with `asyncio.gather`; (c) only call the explainer for hallucinated (not uncertain) claims as a cheap latency win.

- **bm25s vs rank_bm25:** Phase 2 assumes Day 4 Track A is done. If not, the extractor's per-claim retrieval latency will make the demo unusable (80–110s × N claims = bad). Finish Day 4 first.

- **SSE buffering:** some proxies buffer SSE responses. Localhost is fine, but if you ever put nginx in front, you'll need `X-Accel-Buffering: no` on the response.

- **`null` evidence + non-uncertain verdict:** the contract says "If no evidence was found, `evidence` is `null` and the verdict is `uncertain`." Enforce this in Phase 5 — never return e.g. a hallucinated verdict with null evidence, because then the UI has nowhere to point.

- **LLM explanation drift:** llama3.1:8b can hallucinate explanations that contradict the evidence. The prompt template needs to be tight ("explain ONLY based on the snippet provided"). Worth a brief eval in Phase 4 — try 10 hallucinated claims, eyeball the explanations. Anthropic Haiku is noticeably better at following grounding instructions if this becomes a quality issue.

- **LLM extractor JSON failures:** `claim_extractor.py` already has fallback logic (heuristic extractor takes over if the LLM call fails or returns unparseable JSON). This is good defensive design — but it means a silent backend issue could downgrade extraction quality without obvious symptoms. Log every fallback event in the wrapper so you can see in the FastAPI logs when this is happening.

---

## Suggested order of operations (TL;DR)

1. **Day 0:** Make the three decisions, install Ollama, do the pre-flight checklist
2. **Day 1:** Phases 1 + 2 (backend skeleton + extracted modules)
3. **Day 2:** Phases 3 + 4 + 5 (new services + composed pipeline) — first real end-to-end backend
4. **Day 3:** Phase 6 (SSE) + Phase 7 (frontend skeleton)
5. **Day 4:** Phases 8 + 9 + 10 (landing, input, loading)
6. **Day 5–6:** Phase 11 (results — biggest phase, split across two days)
7. **Day 7:** Phases 12 + 13 (error + real SSE wiring) — first real end-to-end webapp
8. **Day 8:** Phase 14 (edge cases) + screenshots for GP report

Roughly one week if focused, two weeks with normal interruptions. Matches the "~2 weeks for RAG integration, ~1 week for web" estimate already in your project plan.
